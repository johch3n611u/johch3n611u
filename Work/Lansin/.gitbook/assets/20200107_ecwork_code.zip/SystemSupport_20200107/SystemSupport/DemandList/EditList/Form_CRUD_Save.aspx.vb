﻿'/////////////////////////////////////////////////////////////////////////////////
' 儲存選單資料 (新增/修改/刪除)
'
' 建檔人員: 育誠
' 建檔日期: 2019-11-27
' 修改記錄: 範例--> 日期 記錄人員 簡述
' 關連程式:
' 呼叫來源: 
'/////////////////////////////////////////////////////////////////////////////////
Imports System.Data
Imports System.Drawing.Imaging
Imports System.IO
Imports System.Net
Imports AmazonUploadFile
Imports EC.Library.Security
Imports Newtonsoft.Json
Imports YahooSCM_API

Partial Class mng_product_list_Form_Save
    Inherits System.Web.UI.Page

    Public prglimit As EC.mng.Limit       '讀取程式的權限

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Response.CacheControl = "no-cache"             '避免被 Cache 住
        EC.mng.Login.LoginCheck()                      '未登入則導到登入頁

        Dim action As String = RequestString("action", RequestActMode.None, RequestMode.XSS)    '空值 or del

        Dim errStatus As String = "ok"
        Dim errMessage As String = "儲存完成"

        prglimit = EC.mng.Limit.CheckLimit(ViewState)    '檢查使用者權限
        If prglimit.errStatus = "error" Then   '權限不符
            errStatus = prglimit.errStatus
            errMessage = prglimit.errMessage
        Else  '儲存

            Dim ListNo As String = Request("ListNo") & ""
            Dim List_Type As String = Request("List_Type") & ""
            Dim Established_No As String = ""
            Dim Urgently_Date As String = Request("Urgently_Date") & ""
            Dim Application_Unit As String = Request("Application_Unit") & ""
            Dim Applicant As String = Request("Applicant") & ""
            Dim Demand_Website As String = Request("Demand_Website") & ""
            Dim Application_Date As String = Request("Application_Date") & ""
            Dim Expected_Runtime As String = Request("Expected_Runtime") & ""
            Dim Quoted_Price As String = Request("Quoted_Price") & ""
            Dim Demand_Description As String = Request("Demand_Description") & ""
            Dim Application_Supervisor As String = Request("Application_Supervisor") & ""
            Dim Engineer_Supervisor As String = Request("Engineer_Supervisor") & ""
            Dim Solution As String = Request("Solution") & ""
            Dim Responsible_Engineer As String = Request("Responsible_Engineer") & ""
            Dim Applicant_Confirmation As String = Request("Applicant_Confirmation") & ""
            Dim Program_Description As String = Request("Program_Description") & ""
            Dim Abstract As String = Request("Abstract") & ""
            Dim Really_Price As String = Request("Really_Price") & ""
            Dim Completion_Date As String = Request("Completion_Date") & ""
            Dim Testers As String = Request("Testers") & ""
            Dim Applicant_Acceptance As String = Request("Applicant_Acceptance") & ""
            Dim REC_Admin_Action As String = Request("REC_Admin_Action") & ""
            Dim REC_Action_Type As String = Request("REC_Action_Type") & ""
            Dim Taxonomy As String = Request("Taxonomy") & ""
            Dim Sorting As String = Request("Sorting") & ""

            Dim Admin As EC.mng.Login = EC.mng.Login.GetSession
            Dim REC_AdminName As String = ""
            Dim REC_Last_Update = Now

            Try

                Select Case List_Type

                    Case "申請"
                        List_Type = "待申請單位主管確認"
                    Case "待申請單位主管確認"
                        List_Type = "待程式人員確認"
                        Dim nowsql As String = "SELECT COUNT(*) FROM SystemSupport_DemandList WITH(NOLOCK) WHERE datediff(Month,getdate(),Postdate) >= 0"
                        Established_No = Format(Now, "yyyy/MM_") + EC.DB.ExecuteDataTable(nowsql).Select().FirstOrDefault.Item(0).ToString
                    Case "待程式人員確認"
                        List_Type = "待申請人確認"
                    Case "待申請人確認"
                        List_Type = "需求單成立"
                    Case "需求單成立"
                        List_Type = "待申請人確認結單"
                    Case "待申請人確認結單"
                        List_Type = "需求單結單"

                End Select




                If ListNo = "" And REC_Action_Type = "新增" Then '新增

                    Dim sqlinsert As String = <sql>
INSERT INTO SystemSupport_DemandList (

List_Type,
Established_No,
Urgently_Date,
Application_Unit,
Applicant,

Demand_Website,
Application_Date,
Expected_Runtime,
Quoted_Price,
Demand_Description,

Application_Supervisor,
Engineer_Supervisor,
Solution,
Responsible_Engineer,
Applicant_Confirmation,

Program_Description,
Abstract,
Really_Price,
Completion_Date,
Testers,

Applicant_Acceptance,

                    Taxonomy,
                    Sorting
                    )

VALUES('{0}',
       '{1}',
       '{2}',
       '{3}',
       '{4}',
       '{5}',
       '{6}',
       '{7}',
       '{8}',
       '{9}',
       '{10}',
       '{11}',
       '{12}',
       '{13}',
       '{14}',
       '{15}',
       '{16}',
       '{17}',
       '{18}',
       '{19}',
       '{20}',
       '{21}',
       '{22}'

                    )

                                              </sql>




                    sqlinsert = String.Format(sqlinsert, List_Type, Established_No, Urgently_Date, Application_Unit, Applicant, Demand_Website, Application_Date, Expected_Runtime, Quoted_Price, Demand_Description, Application_Supervisor, Engineer_Supervisor, Solution, Responsible_Engineer, Applicant_Confirmation, Program_Description, Abstract, Really_Price, Completion_Date, Testers, Applicant_Acceptance, Taxonomy, Sorting)

                    EC.DB.ExecuteScalar(sqlinsert)







                    'REC

                    sqlinsert = "SELECT TOP 1 ListNo FROM SystemSupport_DemandList ORDER BY PostDate DESC"

                    Dim REC_ListNo = EC.DB.ExecuteDataTable(sqlinsert).Select().FirstOrDefault.Item("ListNo").ToString

                    sqlinsert = "INSERT INTO SystemSupport_DemandList_REC(ListNo,REC_AdminName,REC_Action_Type,REC_Admin_Action,REC_Last_Update) VALUES('{0}','{1}','{2}','{3}','{4}')"


                    REC_AdminName = Admin.Name
                    REC_Last_Update = Now
                    sqlinsert = String.Format(sqlinsert, REC_ListNo, REC_AdminName, REC_Action_Type, REC_Admin_Action, REC_Last_Update)
                    EC.DB.ExecuteScalar(sqlinsert)








                ElseIf REC_Action_Type = "修改" Or REC_Action_Type = "提交" Then '修改
                    Dim sqlupdate As String = <sql>
UPDATE SystemSupport_DemandList
SET 

List_Type='{0}',
Established_No='{1}',
Urgently_Date='{2}',
Application_Unit='{3}',
Applicant='{4}',
Demand_Website='{5}',
Application_Date='{6}',
Expected_Runtime='{7}',
Quoted_Price='{8}',
Demand_Description='{9}',
Application_Supervisor='{10}',
Engineer_Supervisor='{11}',
Solution='{12}',
Responsible_Engineer='{13}',
Applicant_Confirmation='{14}',
Program_Description='{15}',
Abstract='{16}',
Really_Price='{17}',
Completion_Date='{18}',
Testers='{19}',
Applicant_Acceptance='{20}',

                    Taxonomy='{22}',
                    Sorting='{23}'

WHERE ListNo='{21}'

                                              </sql>
                    sqlupdate = String.Format(sqlupdate, List_Type, Established_No, Urgently_Date, Application_Unit, Applicant, Demand_Website, Application_Date, Expected_Runtime, Quoted_Price, Demand_Description, Application_Supervisor, Engineer_Supervisor, Solution, Responsible_Engineer, Applicant_Confirmation, Program_Description, Abstract, Really_Price, Completion_Date, Testers, Applicant_Acceptance, ListNo, Taxonomy, Sorting)
                    EC.DB.ExecuteScalar(sqlupdate)






                    'REC

                    Dim REC_ListNo = ListNo

                    sqlupdate = "INSERT INTO SystemSupport_DemandList_REC(ListNo,REC_AdminName,REC_Action_Type,REC_Admin_Action,REC_Last_Update) VALUES('{0}','{1}','{2}','{3}','{4}')"

                    REC_AdminName = Admin.Name
                    REC_Last_Update = Now
                    sqlupdate = String.Format(sqlupdate, REC_ListNo, REC_AdminName, REC_Action_Type, REC_Admin_Action, REC_Last_Update)
                    EC.DB.ExecuteScalar(sqlupdate)


                End If



                Dim Response_ListNo = EC.DB.ExecuteDataTable("SELECT TOP 1 ListNo FROM SystemSupport_DemandList ORDER BY PostDate DESC").Select().FirstOrDefault.Item("ListNo").ToString
                Dim html As String = <html>

                                          &lt;h1&gt;異動成功:資料如下&lt;/h1&gt;
                                          &lt;table&gt;

                                          &lt;tr&gt;
                                             &lt;td&gt;清單編號&lt;/td&gt;
                                             &lt;td&gt;{0}&lt;/td&gt;
                                             &lt;td&gt;異動人&lt;/td&gt;
                                             &lt;td&gt;{1}&lt;/td&gt;
                                             &lt;td&gt;異動狀態&lt;/td&gt;
                                             &lt;td&gt;{2}&lt;/td&gt;
                                             &lt;td&gt;異動動作&lt;/td&gt;
                                             &lt;td&gt;{3}&lt;/td&gt;
                                             &lt;td&gt;異動時間&lt;/td&gt;
                                             &lt;td&gt;{4}&lt;/td&gt;
                                         &lt;/tr&gt;
                                          &lt;tr&gt;
                                             &lt;td&gt;程序&lt;/td&gt;
                                             &lt;td&gt;{5}&lt;/td&gt;
                                             &lt;td&gt;需求單單號&lt;/td&gt;
                                             &lt;td&gt;{6}&lt;/td&gt;
                                             &lt;td&gt;急件日期&lt;/td&gt;
                                             &lt;td&gt;{7}&lt;/td&gt;
                                             &lt;td&gt;申請單位&lt;/td&gt;
                                             &lt;td&gt;{8}&lt;/td&gt;
                                             &lt;td&gt;申請人&lt;/td&gt;
                                             &lt;td&gt;{9}&lt;/td&gt;
                                         &lt;/tr&gt;
                                         &lt;tr&gt;
                                             &lt;td&gt;需求網站&lt;/td&gt;
                                             &lt;td&gt;{10}&lt;/td&gt;
                                             &lt;td&gt;申請日期&lt;/td&gt;
                                             &lt;td&gt;{11}&lt;/td&gt;
                                             &lt;td&gt;期望上線時間&lt;/td&gt;
                                             &lt;td&gt;{12}&lt;/td&gt;
                                             &lt;td&gt;報價&lt;/td&gt;
                                             &lt;td&gt;{13}&lt;/td&gt;
                                             &lt;td&gt;需求描述&lt;/td&gt;
                                             &lt;td&gt;{14}&lt;/td&gt;
                                         &lt;/tr&gt;
                                         &lt;tr&gt;
                                             &lt;td&gt;申請單位主管&lt;/td&gt;
                                             &lt;td&gt;{15}&lt;/td&gt;
                                             &lt;td&gt;接單人&lt;/td&gt;
                                             &lt;td&gt;{16}&lt;/td&gt;
                                             &lt;td&gt;解決方案&lt;/td&gt;
                                             &lt;td&gt;{17}&lt;/td&gt;
                                             &lt;td&gt;工程師&lt;/td&gt;
                                             &lt;td&gt;{18}&lt;/td&gt;
                                             &lt;td&gt;申請人確認&lt;/td&gt;
                                             &lt;td&gt;{19}&lt;/td&gt;
                                         &lt;/tr&gt;
                                         &lt;tr&gt;
                                             &lt;td&gt;程式描述&lt;/td&gt;
                                             &lt;td&gt;{20}&lt;/td&gt;
                                             &lt;td&gt;摘要&lt;/td&gt;
                                             &lt;td&gt;{21}&lt;/td&gt;
                                             &lt;td&gt;實際報價&lt;/td&gt;
                                             &lt;td&gt;{22}&lt;/td&gt;
                                             &lt;td&gt;完成日期&lt;/td&gt;
                                             &lt;td&gt;{23}&lt;/td&gt;
                                             &lt;td&gt;測試人員&lt;/td&gt;
                                             &lt;td&gt;{24}&lt;/td&gt;
                                         &lt;/tr&gt;
                                         &lt;tr&gt;
                                             &lt;td&gt;申請人驗收&lt;/td&gt;
                                             &lt;td&gt;{25}&lt;/td&gt;
                                             &lt;td&gt;分類&lt;/td&gt;
                                             &lt;td&gt;{26}&lt;/td&gt;
                                             &lt;td&gt;狀態&lt;/td&gt;
                                             &lt;td&gt;{27}&lt;/td&gt;
                                             &lt;td colspan="4" style="background-color:white;text-align: center;"&gt;&lt;input type="button" value="儲存" onclick="parent.location.reload();"&gt;&lt;/td&gt;
                                         &lt;/tr&gt;

                                         &lt;/table&gt;
                                         
                                     </html>

                Admin = EC.mng.Login.GetSession
                REC_AdminName = Admin.Name
                REC_Last_Update = Now
                html = String.Format(html, Response_ListNo, REC_AdminName, REC_Action_Type, REC_Admin_Action, REC_Last_Update, List_Type, Established_No, Urgently_Date, Application_Unit, Applicant, Demand_Website, Application_Date, Expected_Runtime, Quoted_Price, Demand_Description, Application_Supervisor, Engineer_Supervisor, Solution, Responsible_Engineer, Applicant_Confirmation, Program_Description, Abstract, Really_Price, Completion_Date, Testers, Applicant_Acceptance, ListNo, Taxonomy, Sorting)



                Response.Write(html)

            Catch ex As Exception
                Response.Write("資料儲存失敗，錯誤訊息為:" + ex.Message)
            End Try

        End If

    End Sub



End Class




