﻿'/////////////////////////////////////////////////////////////////////////////////
' 儲存 (新增/修改/刪除)
'
' 建檔人員: 阿友
' 建檔日期: 2013-08-28
' 修改記錄: 範例--> 日期 記錄人員 簡述
' 關連程式:
' 呼叫來源: 
'/////////////////////////////////////////////////////////////////////////////////
Imports System.IO
Imports EC.Library.Security
Partial Class mng_ShoppingCash_SC_UserList_Form_Del
    Inherits System.Web.UI.Page

    Public prglimit As EC.mng.Limit       '讀取程式的權限


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Response.CacheControl = "no-cache"             '避免被 Cache 住
        EC.mng.Login.LoginCheck()                      '未登入則導到登入頁

        Dim action As String = RequestString("action", RequestActMode.None, RequestMode.XSS)    '空值 or del
        Dim delProductNo = Request("delProductNo")
        Dim errStatus As String = "成功"
        Dim errMessage As String = "成功刪除" + delProductNo

        prglimit = EC.mng.Limit.CheckLimit(ViewState)    '檢查使用者權限
        If prglimit.errStatus = "error" Then   '權限不符
            errStatus = prglimit.errStatus
            errMessage = prglimit.errMessage
        Else  '儲存

            If delProductNo = "" Then '刪除全部

                EC.DB.ExecuteScalar("DELETE FROM Unitech_list")
                errMessage = "刪除成功"
            ElseIf delProductNo <> "" Then '刪除特定

                Dim delProductNos() = Split(delProductNo, ",")
                Dim Product = ""
                For num As Integer = 0 To delProductNos.Count - 1 Step 1

                    Product += "'" + delProductNos(num) + "'"

                Next

                Dim DELSQL As String = "DELETE FROM Unitech_list WHERE ProductNo in ({0})"
                DELSQL = String.Format(DELSQL, Product)

                EC.DB.ExecuteScalar(DELSQL)


            End If

        End If
        Response.Write("{""status"": """ & errStatus & """, ""message"":""" & errMessage & """}")

    End Sub

End Class
