﻿'/////////////////////////////////////////////////////////////////////////////////
' Sastty 問券調查
' 建檔日期: 2020-01-15
' 建檔人員: 育誠
' 修改記錄: 
' 呼叫來源: 
'/////////////////////////////////////////////////////////////////////////////////
Imports System.Data
Imports Shop.Library.Security
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Shop

Partial Class survey_Default
    Inherits System.Web.UI.Page

    Public shopid As Integer = Shop.SiteInfo.shopid     '廠商編號
    Public cateStr As String = "A1"      '對應到ucMenu.ascx的div id(我的帳戶管理=A)
    Public timer As String = Shop.Library.Security.TimeStamp

    Public memberNO As String = ""
    Public memberName As String = ""
    Public memberEmail As String = ""

    Public TYPE As String = ""
    Public Buydate_Y As String = ""
    Public Buydate_M As String = ""
    Public Buydate_D As String = ""
    Public CHNL_ID As String = ""
    Public BuyFromWhere As String = ""

    Public DeliverCity As String = ""
    Public DeliverState As String = ""

    Public jsScript As String = ""
    Public jsCode As String = ""
    Dim sql As String = ""

    Public Javascript As String = ""

    Public UserName As String = ""
    Public UserMobile As String = ""

    ''' <summary>
    ''' 取消 ViewState ,避免 index_body.aspx 使用 ajax 呼叫 ajaxCartList.aspx 時造成 ViewState 重覆出現的問題
    ''' </summary>
    ''' <param name="writer"><see cref="T:System.Web.UI.HtmlTextWriter" />，接收頁面內容。</param>
    Protected Overrides Sub Render(ByVal writer As System.Web.UI.HtmlTextWriter)
        Dim content As String = String.Empty
        Dim stringWriter As New IO.StringWriter()
        Dim htmlWriter As New HtmlTextWriter(stringWriter)
        Try
            ' 將當前頁面的內容呈現到臨時的HtmlTextWriter 對像中
            MyBase.Render(htmlWriter)
            htmlWriter.Close()
            content = stringWriter.ToString()    '得到當前頁面的全部內容

            Dim newContent As String = Shop.Library.HTTP.RemoveViewState(content)  '移除 ViewState 
            writer.Write(newContent)   ' 將新頁面的內容顯示出來
        Catch e As Exception

        Finally
            stringWriter.Dispose()
            htmlWriter.Close()
            htmlWriter.Dispose()
        End Try
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        '判斷是否有登入
        Dim isGo2LoginForm As Boolean = False
        Dim islogin As Boolean = Shop.Member.ISLogin
        Dim ISLocalDomain As Boolean = Shop.Library.Site.ISLocalDomain

        If Not islogin Then  '未登入
            isGo2LoginForm = True
        Else 'For test (2012-01-19 友)
            'Shop.Member.Logout()
        End If

        '表單Submit,不再判斷是否已登入,以免逾時狀況時資料無法存入.
        If Request.RequestType = "POST" And (Request.Form("name") & "") <> "" And (Request.Form("email") & "") <> "" Then
            isGo2LoginForm = False
        End If

        '未登入 且 不是表單SUBMIT
        If isGo2LoginForm Then
            '判斷 URL 是否有使用 https , 如無則 submit action 改為 https 的URL,再 submit 給自己.
            Dim URL As String = "/personal/login.aspx"
            If Request.ServerVariables("HTTPS") = "off" And ISLocalDomain = False Then
                URL = "https://" & Request.ServerVariables("SERVER_NAME") & "/Personal/login.aspx"
            End If

            With Response
                .Write("<script src='/lib/jQuery/jquery-1.7.2.min.js' type='text/javascript'></script>")
                .Write("<form id='frmReg' action='" & URL & "' method='post'>")
                .Write("<input type='hidden' name='backurl' value='/survey/Default.aspx'>")
                .Write("</form>")
                .Write("<script>$('#frmReg').submit();</script>")
            End With
            Response.End()
        End If

        '取出產品型號清單

        'sql = <a>
        '          SELECT [OwnMenNo] FROM Shop_Member
        '      </a>
        'Dim dr As DataTable = Shop.DB.ExecuteDataTable(sql)

        '以上無修改，以下為2019/0805/修改內容

        memberNO = Session("memberNO")
        memberName = Session("MemberName")
        memberEmail = Session("MemberEmail")

        Dim SQL As String = "SELECT * FROM Shop_Member WITH(NOLOCK) WHERE cno = '{0}'"
        SQL = String.Format(SQL, memberNO)
        Dim dt As DataTable = Shop.DB.ExecuteDataTable(SQL)
        If dt.Rows.Count > 0 Then
            UserMobile = dt.Select().FirstOrDefault.Item("Mobil").ToString
        End If

        Dim confirmCode2 As String = Session("_ValCheckCodeqa")

        Dim Name As String = XSS_SQLIJ(Request.Form("Name") & "")               '會員姓名
        Dim Birthday As String = XSS_SQLIJ(Request.Form("Birthday") & "")       '生日
        Dim MobilePhone As String = XSS_SQLIJ(Request.Form("MobilePhone") & "") '手機

        Dim BrDintYear As String = XSS_SQLIJ(Request.Form("BrDintYear") & "")   '會員生日
        Dim BrDintMonth As String = XSS_SQLIJ(Request.Form("BrDintMonth") & "")
        Dim BrDintDay As String = XSS_SQLIJ(Request.Form("BrDintDay") & "")

        Birthday = BrDintYear + "/" + BrDintMonth + "/" + BrDintDay

        Dim Q1 As String = XSS_SQLIJ(Request.Form("Q1") & "")   '問卷內容
        Dim Q2 As String = XSS_SQLIJ(Request.Form("Q2") & "")
        Dim Q3 As String = XSS_SQLIJ(Request.Form("Q3") & "")
        Dim Q4 As String = XSS_SQLIJ(Request.Form("Q4") & "")
        Dim Q5 As String = XSS_SQLIJ(Request.Form("Q5") & "")

        'Dim dtFinal As DataTable

        '確認是否是登入帳號
        Dim FirstPage = Request("FirstPage") + ""
        If FirstPage = "FirstPage" Then

            '驗證完成執行資料存庫與頁面轉跳

            SQL = <a>
                  INSERT INTO Shop_Survey
                  (memberNO,[Name],MobilePhone,Birthday,Q1,Q2,Q3,Q4,Q5)
                  VALUES
                  ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')
              </a>
            SQL = String.Format(SQL, memberNO, [Name], MobilePhone, Birthday, Q1, Q2, Q3, Q4, Q5)
            Shop.DB.ExecuteNonQuery(SQL)


            '更新 Shop_Member 資料 Birthday、Mobil

            SQL = <SQL>
                      UPDATE Shop_Member
                      SET Birthday = '{0}' , Mobil = '{1}'
                      WHERE cno = '{2}'
                  </SQL>
            SQL = String.Format(SQL, Birthday, MobilePhone, memberNO)
            Shop.DB.ExecuteNonQuery(SQL)


            Response.Write("<script>if(confirm('謝謝您的回饋，好禮將會於48小時內匯入您的官網會員帳戶，期待下次再見！按下確認，將會幫您返回首頁。')){document.location = '/';}else{window.history.go(-1); }</script>")


        End If

    End Sub

    ''' <summary>
    ''' 設定 SEO
    ''' </summary>
    Sub SEOSetting()
        Page.Title = "產品登錄 - " & Shop.SiteInfo.WebTitle
        'Page.MetaKeywords = meta_keywords
        'Page.MetaDescription = meta_description
    End Sub
End Class