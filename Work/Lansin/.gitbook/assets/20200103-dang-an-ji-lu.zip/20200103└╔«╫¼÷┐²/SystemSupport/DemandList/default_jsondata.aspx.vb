﻿'/////////////////////////////////////////////////////////////////////////////////
' 取 default 主頁資料 (json 格式)
'
' 建檔人員: 譓茹
' 建檔日期: 2018-05-21
' 修改記錄:
' 關連程式:
' 呼叫來源: /mng/CRM/RFML/Default.aspx
'/////////////////////////////////////////////////////////////////////////////////
Imports System.Data
Imports EC.Library.Security
Partial Class mng_CRM_RFML_default_jsondata
    Inherits System.Web.UI.Page

    Public PrgID As String = ""
    Public prglimit As EC.mng.Limit       '讀取程式的權限

    Public total As Integer = 0

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Response.CacheControl = "no-cache"    '避免被 Cache 住 
        EC.mng.Login.LoginCheck()             '未登入者導到登入頁


        Dim selSort As String = SQLIJ(Request("Sort"))                  '排序欄位
        Dim selOrder As String = SQLIJ(Request("Order"))                '排序方式: asc / desc
        Dim CurrentPage As Integer = SQLIJ(Request("page"))             '跳到N頁
        Dim PageSize As Integer = SQLIJ(Request("rows"))                '每頁筆數

        If String.IsNullOrWhiteSpace(selSort) Then selSort = "Sorting asc,Established_No "
        If String.IsNullOrWhiteSpace(selOrder) Then selOrder = "desc"
        If Not IsNumeric(CurrentPage) Then CurrentPage = 1
        If CurrentPage < 1 Then CurrentPage = 1
        If PageSize <= 1 Then PageSize = 15

        Dim dt As DataTable = New DataTable

        Dim keywords As String = Request("keywords") + ""

        If Not String.IsNullOrWhiteSpace(keywords) Then

            Dim Sql = "SELECT * FROM SystemSupport_DemandList WITH(NOLOCK)"
            Dim Where = "Established_No LIKE '%{0}%'"
            Where = String.Format(Where, keywords)
            Dim Orderby As String = selSort & " " & selOrder
            Dim ds As DataSet = EC.DB.Paging2005.ExecuteDataSet(PageSize, CurrentPage, Sql, Where, Orderby, False)
            dt = ds.Tables(0)

            total = ds.Tables("TableRowsOut").Rows(0).Item("Count")           '總筆數

        Else

            Dim Sql = "SELECT * FROM SystemSupport_DemandList WITH(NOLOCK)"
            Dim Where = ""
            Dim Orderby As String = selSort & " " & selOrder
            Dim ds As DataSet = EC.DB.Paging2005.ExecuteDataSet(PageSize, CurrentPage, Sql, Where, Orderby, False)
            dt = ds.Tables(0)

            total = ds.Tables("TableRowsOut").Rows(0).Item("Count")           '總筆數

            'Dim dt As DataTable = EC.DB.ExecuteDataTable("SELECT * FROM SystemSupport_DemandList WITH(NOLOCK) WHERE  ListNo in ('75') ORDER BY Sorting ASC")

            'total = dt.Rows.Count '總筆數


        End If

        With rptdata
            .DataSource = dt
            .DataBind()
        End With

    End Sub
End Class
