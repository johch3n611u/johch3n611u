﻿'/////////////////////////////////////////////////////////////////////////////////
' 需求單清單
' 建檔人員: 育誠
' 建檔日期: 2020-01-08
' 修改記錄: 
' 關連程式:
' 呼叫來源:
'/////////////////////////////////////////////////////////////////////////////////
Imports EC.Library.Security
Imports System.Data
Partial Class mng_CRM_RFML_Default
    Inherits System.Web.UI.Page

    Public prgname As String = "需求單管理"
    Public PrgID As String = ""
    Public prglimit As EC.mng.Limit       '讀取程式的權限
    Public _currentPath As String = EC.Library.Site.GetCurrentPath   'ex: /mng/Product/Category/LargeNo/

    Dim sql As String = ""
    Dim tb As DataTable = New DataTable


    'chart.js
    Public labels As String = ""
    Public data As String = ""


    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Response.CacheControl = "no-cache"             '避免被 Cache 住
        EC.mng.Login.LoginCheck()                      '未登入則導到登入頁
        prglimit = New EC.mng.Limit(ViewState)         '讀取程式的權限
        PrgID = EC.mng.Limit.GetPrgID(ViewState)

        'chart.js
        sql =
<SQL>
SELECT Application_Unit FROM SystemSupport_DemandList With(NOLOCK) 
WHERE 
Application_Unit IS NOT NULL 
AND Application_Unit &lt;&gt; '' 
AND Applicant_Acceptance = '已驗收'
GROUP BY Application_Unit
</SQL>

        'sql = String.Format(sql, Now.ToString("yyyyMM")) 'Established_No Like '%{0}%'
        tb = EC.DB.ExecuteDataTable(sql)

        Dim list As New List(Of String)
        For num As Integer = 0 To tb.Rows.Count - 1 Step 1
            '查部門名稱
            Dim Application_Unit = tb.Rows.Item(num).Item("Application_Unit").ToString
            list.Add(Application_Unit)






            '查出資料後加總
            Dim datasql As String =
<SQL>
SELECT Really_Price FROM SystemSupport_DemandList With(NOLOCK) 
WHERE Application_Unit = '{0}'
AND Applicant_Acceptance = '已驗收'
AND Really_Price &lt;&gt; '' 
AND Really_Price IS NOT NULL 
</SQL>
            'datasql = String.Format(datasql, Now.ToString("yyyyMM")) 'Established_No Like '%{0}%'
            datasql = String.Format(datasql, Application_Unit)
            Dim RP_dt = EC.DB.ExecuteDataTable(datasql)
            Dim RP_Count As Integer = 0

            For num2 As Integer = 0 To RP_dt.Rows.Count - 1 Step 1

                RP_Count += CInt(RP_dt.Rows.Item(num2).Item("Really_Price"))

            Next


            Dim datastring = "'" + CStr(RP_Count) + "'"
            If num <> tb.Rows.Count - 1 Then

                datastring += ","

            End If
            data += datastring







            '查部門名稱
            Dim Application_UnitS() As String = Application_Unit.Split("／")
            If Application_UnitS.Count > 1 Then
                Application_Unit = Application_UnitS(1)
            Else
                Application_Unit = Application_UnitS(0)
            End If

            Dim labelsstring = "'" + Application_Unit + "'"
            If num <> tb.Rows.Count - 1 Then

                labelsstring += ","

            End If
            labels += labelsstring
        Next






    End Sub
End Class
