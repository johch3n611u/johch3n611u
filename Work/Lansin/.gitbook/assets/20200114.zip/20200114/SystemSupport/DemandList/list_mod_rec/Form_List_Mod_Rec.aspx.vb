﻿'/////////////////////////////////////////////////////////////////////////////////
' 需求單異動紀錄
' 建檔人員: 育誠
' 建檔日期: 2020-01-08
' 修改記錄: 
' 關連程式:
' 呼叫來源:
'/////////////////////////////////////////////////////////////////////////////////
Imports System.Data
Imports EC.Library.Security

Partial Class mng_product_list_Form_List_Mod_Rec
    Inherits System.Web.UI.Page

    Public cno As Integer = 0
    Public list_NewCNO As Integer = 0
    Public productname As String = ""      '產品名稱
    Public _Count As Integer = 0           '資料總筆數
    Public _TopN As Integer = 100          '顯示筆數

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Response.CacheControl = "no-cache"    '避免被 Cache 住 

        Dim ISAdministrator_Or_ISDeveloper As Boolean = EC.mng.Func.User_ISAdministrator_Or_ISDeveloper()


        Dim ListNo = Request("ListNo") & ""
        Dim RECsql As String = "SELECT TOP 100 * FROM SystemSupport_DemandList_REC WITH(NOLOCK) WHERE ListNo = '{0}' ORDER BY REC_Last_Update"
        RECsql = String.Format(RECsql, ListNo)
        Dim RECdt = EC.DB.ExecuteDataTable(RECsql)
        _Count = RECdt.Rows.Count
        With rpt_list_mod_rec
            .DataSource = RECdt
            .DataBind()
        End With



    End Sub

End Class
