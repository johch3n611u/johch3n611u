﻿'/////////////////////////////////////////////////////////////////////////////////
' 儲存 (新增/修改/刪除)
'
' 建檔人員: 阿友
' 建檔日期: 2013-08-28
' 修改記錄: 範例--> 日期 記錄人員 簡述
' 關連程式:
' 呼叫來源: 
'/////////////////////////////////////////////////////////////////////////////////
Imports System.Data
Imports System.IO
Imports EC.Library.Security
Partial Class mng_ShoppingCash_SC_UserList_Form_CRUD_Save
    Inherits System.Web.UI.Page
    Public PrgID As String = ""
    Public _ID As Integer = 0
    Public tb As New Ls3c_v2_2005.ShoppingCash_UserGroup
    Public GroupUseEvtNosStatus As String = ""
    Public prglimit As EC.mng.Limit       '讀取程式的權限

    Public savetype As String = "" ' (first enter) 新增 / 修改 / (second enter) 儲存 /
    Public ListNo As String = "" '需求單流水號
    Public SupplementNo As String = "" '備註流水號
    Public Demand_Supplement As String = "" '備註
    Public Message_From As String = "" '留言者


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Response.CacheControl = "no-cache"             '避免被 Cache 住
        EC.mng.Login.LoginCheck()                      '未登入則導到登入頁

        Dim action As String = RequestString("action", RequestActMode.None, RequestMode.XSS)    '空值 or del

        Dim REC_Action_Type As String = ""
        Dim REC_Admin_Action As String = ""

        prglimit = EC.mng.Limit.CheckLimit(ViewState)    '檢查使用者權限
        'PrgID = SQLIJ(Request("PrgID"))                '主選單的MENUID,判斷權限使用.
        '_ID = RequestNumeric("ID", RequestActMode.None, RequestMode.SQLInjection)
        'If prglimit.errStatus = "error" Then   '權限不符
        'Else  '儲存
        'Response.Redirect("/mng/SystemSupport/DemandList/Demand_Supplement/Form_CRUD.aspx")
        'End If

        savetype = Request("savetype") + "" '(first enter) 新增 / 修改 / (second enter) 儲存 /
        ListNo = Request("ListNo") + ""
        SupplementNo = Request("SupplementNo") + ""
        Dim changeNo = "SupplementNo" + Request("changeNo")



        If savetype = "修改" Then
            SupplementNo = Request(changeNo)
            Dim sql As String = <sql>

                                    Select * FROM SystemSupport_DemandList_Supplement WITH(NOLOCK)
                                    WHERE SupplementNo = '{0}'

                                </sql>
            sql = String.Format(sql, SupplementNo)
            Dim dt As DataTable = EC.DB.ExecuteDataTable(sql)
            Demand_Supplement = dt.Select().FirstOrDefault.Item("Demand_Supplement").ToString

        ElseIf savetype = "儲存" Then

            Demand_Supplement = Request("Demand_Supplement") + ""
            Dim Admin As EC.mng.Login = EC.mng.Login.GetSession
            Message_From = Admin.Name

            Try

                Dim sql As String = ""
                Dim PostDate As String = Now
                If SupplementNo <> "" Then

                    sql = <sql>

                              UPDATE SystemSupport_DemandList_Supplement
                              SET ListNo = '{0}',PostDate = '{1}' , Demand_Supplement = '{2}' , Message_From = '{3}'
                              WHERE SupplementNo = '{4}'

                          </sql>

                    sql = String.Format(sql, ListNo, PostDate, Demand_Supplement, Message_From, SupplementNo)
                    EC.DB.ExecuteScalar(sql)
                    REC_Action_Type = "修改"
                Else

                    sql = <sql>

                              INSERT INTO SystemSupport_DemandList_Supplement (ListNo, PostDate, Demand_Supplement, Message_From)
                              VALUES ('{0}','{1}','{2}','{3}');

                          </sql>

                    sql = String.Format(sql, ListNo, PostDate, Demand_Supplement, Message_From)
                    EC.DB.ExecuteScalar(sql)
                    REC_Action_Type = "新增"
                End If

                'REC
                Dim REC_ListNo = ListNo
                Dim sqlinsert = "INSERT INTO SystemSupport_DemandList_REC(ListNo,REC_AdminName,REC_Action_Type,REC_Admin_Action,REC_Last_Update) VALUES('{0}','{1}','{2}','{3}','{4}')"
                Dim REC_AdminName = Admin.Name
                Dim REC_Last_Update = Now
                REC_Admin_Action = "備註"
                sqlinsert = String.Format(sqlinsert, REC_ListNo, REC_AdminName, REC_Action_Type, REC_Admin_Action, REC_Last_Update)
                EC.DB.ExecuteScalar(sqlinsert)

                Response.Redirect("/mng/SystemSupport/DemandList/Demand_Supplement/Form_CRUD.aspx?ListNo=" + ListNo)

            Catch ex As Exception

                Dim exmsg As String = "<script>alert('儲存錯誤!錯誤訊息為:{0}')</script>"
                exmsg = String.Format(exmsg, ex.Message)
                Response.Write(exmsg)

            End Try

        End If








    End Sub

End Class
