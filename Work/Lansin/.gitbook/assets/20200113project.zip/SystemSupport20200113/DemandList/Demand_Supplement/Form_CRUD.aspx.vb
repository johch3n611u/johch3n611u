﻿'/////////////////////////////////////////////////////////////////////////////////
' 表單 (新增/修改)
'
' 建檔人員: 阿友
' 建檔日期: 2013-08-28
' 修改記錄: 範例--> 日期 記錄人員 簡述
' 關連程式: 
' 呼叫來源: 
'/////////////////////////////////////////////////////////////////////////////////
Imports EC.Library.Security
Imports System.Data
Partial Class mng_ShoppingCash_SC_UserList_Form_CRUD
    Inherits System.Web.UI.Page


    Public PrgID As String = ""
    Public prglimit As EC.mng.Limit       '讀取程式的權限
    Public _ID As Integer = 0
    Public tb As New Ls3c_v2_2005.ShoppingCash_UserGroup
    Public GroupUseEvtNosStatus As String = ""

    Public ListNo As String = ""
    Public Message_From As String = ""
    Public dt As DataTable = New DataTable
    Public Supplements As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Response.CacheControl = "no-cache"             '避免被 Cache 住
        EC.mng.Login.LoginCheck()                      '未登入則導到登入頁
        prglimit = New EC.mng.Limit(ViewState)         '讀取程式的權限

        PrgID = SQLIJ(Request("PrgID"))                '主選單的MENUID,判斷權限使用.
        _ID = RequestNumeric("ID", RequestActMode.None, RequestMode.SQLInjection)

        If Not IsNumeric(_ID) Then _ID = 0

        ListNo = Request("ListNo") + ""
        Dim Admin As EC.mng.Login = EC.mng.Login.GetSession
        Message_From = Admin.Name


        Dim sql As String = <sql>

                                Select * FROM SystemSupport_DemandList_Supplement WITH(NOLOCK) 
                                WHERE ListNo = '{0}' ORDER BY SupplementNo

                            </sql>
        sql = String.Format(sql, ListNo)
        dt = EC.DB.ExecuteDataTable(sql)

        If dt.Rows.Count > 0 Then

            For num As Integer = 0 To dt.Rows.Count - 1 Step 1

                Dim html As String = <html>

                                         &lt;tr&gt;
                                             &lt;td class="bg" width="80"&gt;姓名&lt;/td&gt;
                                             &lt;td&gt;{0}&lt;/td&gt;
                                             &lt;td class="bg" width="80"&gt;時間&lt;/td&gt;
                                             &lt;td&gt;{1}&lt;/td&gt;
                                         &lt;/tr&gt;
                                         &lt;tr&gt;
                                             &lt;td class="bg"&gt;備&lt;/br&gt;註&lt;/td&gt;
                                             &lt;td colspan="3"&gt;{2}&lt;/td&gt;
                                         &lt;/tr&gt;
                                         &lt;tr &gt;
                                             &lt;td colspan = "4" align="center"&gt;
                                                &lt;input style = "display:none;" id="SupplementNo{3}" name="SupplementNo{3}"/ value="{3}"&gt;
                                                &lt;a href = "#" onclick="javascript:submitonclick('新增','');" Class="easyui-linkbutton" icon="icon-ok"&gt;新增&lt;/a&gt;
                                                &lt;a href = "#" onclick="javascript:submitonclick('修改','{3}');" Class="easyui-linkbutton" icon="icon-ok"&gt;修改&lt;/a&gt;
                                             &lt;/td&gt;
                                         &lt;/tr&gt;

                                     </html>

                Dim PostDate As String = dt.Rows.Item(num).Item("PostDate").ToString
                Dim Demand_Supplement As String = dt.Rows.Item(num).Item("Demand_Supplement").ToString
                Dim SupplementNo As String = dt.Rows.Item(num).Item("SupplementNo").ToString
                html = String.Format(html, Message_From, PostDate, Demand_Supplement, SupplementNo)

                Supplements += html
            Next

        End If

    End Sub

End Class
