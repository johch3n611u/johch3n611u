﻿'/////////////////////////////////////////////////////////////////////////////////
' 需求單圖表
' 建檔人員: 育誠
' 建檔日期: 2020-01-08
' 修改記錄: 
' 關連程式:
' 呼叫來源:
'/////////////////////////////////////////////////////////////////////////////////
Imports EC.Library.Security
Imports System.Data
Partial Class mng_CRM_RFML_Default
    Inherits System.Web.UI.Page

    Public prgname As String = "需求單管理"
    Public PrgID As String = ""
    Public prglimit As EC.mng.Limit       '讀取程式的權限
    Public _currentPath As String = EC.Library.Site.GetCurrentPath   'ex: /mng/Product/Category/LargeNo/

    Dim sql As String = ""
    Dim tb As DataTable = New DataTable
    Public nowDate As String = ""

    'chart.js
    Public labels As String = ""
    Public data As String = ""


    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load



        nowDate = Now.ToString("yyyyMM")


        Response.CacheControl = "no-cache"             '避免被 Cache 住
        EC.mng.Login.LoginCheck()                      '未登入則導到登入頁
        prglimit = New EC.mng.Limit(ViewState)         '讀取程式的權限
        PrgID = EC.mng.Limit.GetPrgID(ViewState)

        'chart.js
        sql =
<SQL>
SELECT Taxonomy FROM SystemSupport_DemandList With(NOLOCK) 
WHERE 
Taxonomy IS NOT NULL 
AND Taxonomy &lt;&gt; '' 
AND Applicant_Acceptance = '已驗收'
AND Established_No Like '%{0}%'
GROUP BY Taxonomy
</SQL>

        sql = String.Format(sql, nowDate) 'Established_No Like '%{0}%'
        tb = EC.DB.ExecuteDataTable(sql)

        Dim list As New List(Of String)
        For num As Integer = 0 To tb.Rows.Count - 1 Step 1
            '查部門名稱
            Dim Taxonomy = tb.Rows.Item(num).Item("Taxonomy").ToString
            list.Add(Taxonomy)

            '查出資料後加總
            Dim datasql As String =
<SQL>
SELECT Really_Price FROM SystemSupport_DemandList With(NOLOCK) 
WHERE Taxonomy = '{0}'
AND Applicant_Acceptance = '已驗收'
AND Really_Price &lt;&gt; '' 
AND Really_Price IS NOT NULL 
AND Established_No Like '%{1}%'
</SQL>
            'datasql = String.Format(datasql, Now.ToString("yyyyMM")) 'Established_No Like '%{0}%'
            datasql = String.Format(datasql, Taxonomy, nowDate)
            Dim RP_dt = EC.DB.ExecuteDataTable(datasql)
            Dim RP_Count As Integer = 0

            For num2 As Integer = 0 To RP_dt.Rows.Count - 1 Step 1

                RP_Count += CInt(RP_dt.Rows.Item(num2).Item("Really_Price"))

            Next


            Dim datastring = "'" + CStr(RP_Count) + "'"
            If num <> tb.Rows.Count - 1 Then

                datastring += ","

            End If
            data += datastring

            '查部門名稱
            Dim Application_UnitS() As String = Taxonomy.Split("／")
            If Application_UnitS.Count > 1 Then
                Taxonomy = Application_UnitS(1)
            Else
                Taxonomy = Application_UnitS(0)
            End If

            Dim labelsstring = "'" + Taxonomy + "'"
            If num <> tb.Rows.Count - 1 Then

                labelsstring += ","

            End If
            labels += labelsstring
        Next

    End Sub
End Class
