﻿'/////////////////////////////////////////////////////////////////////////////////
' 表單 (新增/修改)
'
' 建檔人員: 育誠
' 建檔日期: 2019-11-27
' 修改記錄: 範例--> 日期 記錄人員 簡述
' 關連程式: 
' 呼叫來源: 
'/////////////////////////////////////////////////////////////////////////////////
Imports EC.Library.Security
Imports System.Data


Partial Class mng_product_list_Form
    Inherits System.Web.UI.Page

    Public PrgID As String = ""
    Public prglimit As EC.mng.Limit       '讀取程式的權限
    Public _ID As Integer = 0

    Public List_Type = ""
    Public ListNo = ""
    Public tb As DataTable = New DataTable
    Public Established_No As String = ""
    Public Urgently_Date As String = ""
    Public Application_Unit As String = ""
    Public Applicant As String = ""
    Public Demand_Website As String = ""
    Public Application_Date As String = ""
    Public Expected_Runtime As String = ""
    Public Quoted_Price As String = ""
    Public Demand_Description As String = ""
    Public Application_Supervisor As String = ""
    Public Engineer_Supervisor As String = ""
    Public Solution As String = ""
    Public Responsible_Engineer As String = ""
    Public Applicant_Confirmation As String = ""
    Public Program_Description As String = ""
    Public Abstract As String = ""
    Public Really_Price As String = ""
    Public Completion_Date As String = ""
    Public Testers As String = ""
    Public Applicant_Acceptance As String = ""

    Public Taxonomy As String = ""
    Public Sorting As String = ""

    Public Unit_Names As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Response.CacheControl = "no-cache"             '避免被 Cache 住
        EC.mng.Login.LoginCheck()                      '未登入則導到登入頁
        prglimit = New EC.mng.Limit(ViewState)         '讀取程式的權限

        PrgID = SQLIJ(Request("PrgID"))                '主選單的MENUID,判斷權限使用.
        _ID = RequestNumeric("ID", RequestActMode.None, RequestMode.SQLInjection)

        ListNo = Request("ListNo") & ""

        '正常讀取頁面

        If Not IsNumeric(_ID) Then _ID = 0

        Application_Date = Now.ToString("yyyy-MM-dd")
        Dim Admin = EC.mng.Login.GetSession
        Applicant = Admin.Name

        '取資料
        If _ID > 0 Then   'Modify

            If ListNo <> "" Then

                Dim sql As String = "SELECT * FROM SystemSupport_DemandList WITH(NOLOCK) WHERE ListNo = '{0}'"
                sql = String.Format(sql, ListNo)
                tb = EC.DB.ExecuteDataTable(sql)
                List_Type = tb.Select().FirstOrDefault.Item("List_Type").ToString

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Established_No").ToString) Then
                    Established_No = tb.Select().FirstOrDefault.Item("Established_No").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Urgently_Date").ToString) Then
                    Urgently_Date = tb.Select().FirstOrDefault.Item("Urgently_Date").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Application_Unit").ToString) Then
                    Application_Unit = tb.Select().FirstOrDefault.Item("Application_Unit").ToString()
                    Application_Unit = "<option selected='selected' value='" + Application_Unit + "'>" + Application_Unit + "</option>"
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Applicant").ToString) Then
                    Applicant = tb.Select().FirstOrDefault.Item("Applicant").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Demand_Website").ToString) Then
                    Demand_Website = tb.Select().FirstOrDefault.Item("Demand_Website").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Application_Date").ToString) Then
                    Application_Date = tb.Select().FirstOrDefault.Item("Application_Date").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Expected_Runtime").ToString) Then
                    Expected_Runtime = tb.Select().FirstOrDefault.Item("Expected_Runtime").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Quoted_Price").ToString) Then
                    Quoted_Price = tb.Select().FirstOrDefault.Item("Quoted_Price").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Demand_Description").ToString) Then
                    Demand_Description = tb.Select().FirstOrDefault.Item("Demand_Description").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Application_Supervisor").ToString) Then
                    Application_Supervisor = tb.Select().FirstOrDefault.Item("Application_Supervisor").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Engineer_Supervisor").ToString) Then
                    Engineer_Supervisor = tb.Select().FirstOrDefault.Item("Engineer_Supervisor").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Solution").ToString) Then
                    Solution = tb.Select().FirstOrDefault.Item("Solution").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Responsible_Engineer").ToString) Then
                    Responsible_Engineer = tb.Select().FirstOrDefault.Item("Responsible_Engineer").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Applicant_Confirmation").ToString) Then
                    Applicant_Confirmation = tb.Select().FirstOrDefault.Item("Applicant_Confirmation").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Program_Description").ToString) Then
                    Program_Description = tb.Select().FirstOrDefault.Item("Program_Description").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Abstract").ToString) Then
                    Abstract = tb.Select().FirstOrDefault.Item("Abstract").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Really_Price").ToString) Then
                    Really_Price = tb.Select().FirstOrDefault.Item("Really_Price").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Really_Price").ToString) Then
                    Really_Price = tb.Select().FirstOrDefault.Item("Really_Price").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Completion_Date").ToString) Then
                    Completion_Date = tb.Select().FirstOrDefault.Item("Completion_Date").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Testers").ToString) Then
                    Testers = tb.Select().FirstOrDefault.Item("Testers").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Applicant_Acceptance").ToString) Then
                    Applicant_Acceptance = tb.Select().FirstOrDefault.Item("Applicant_Acceptance").ToString
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Taxonomy").ToString) Then
                    Taxonomy = tb.Select().FirstOrDefault.Item("Taxonomy").ToString()
                    Taxonomy = "<option selected='selected' value='" + Taxonomy + "'>" + Taxonomy + "</option>"
                End If

                If Not Convert.IsDBNull(tb.Select().FirstOrDefault.Item("Sorting").ToString) Then
                    Sorting = tb.Select().FirstOrDefault.Item("Sorting").ToString
                    Dim SortingText = ""
                    Select Case Sorting
                        Case "1"
                            SortingText = "進行中"
                        Case "2"
                            SortingText = "排序1"
                        Case "3"
                            SortingText = "排序2"
                        Case "4"
                            SortingText = "排序3"
                        Case "999"
                            SortingText = "已結案"
                    End Select

                    Sorting = "<option selected='selected' value='" + Sorting + "'>" + SortingText + "</option>"

                End If



            End If

        End If

        'Unit_Names = "<option value''>未選擇</option>"
        'Dim UnitSQL As String = "SELECT Unit_Name FROM Admin_Manager WITH(NOLOCK) WHERE Unit_Name IS NOT NULL GROUP BY Unit_Name "
        'Dim Unitdt = EC.DB.ExecuteDataTable(UnitSQL)
        'For num As Integer = 0 To Unitdt.Rows.Count - 1 Step 1

        '    Dim unitstring = Unitdt.Rows.Item(num).Item("Unit_Name").ToString
        '    Dim unititem = "<option value'" + unitstring + "'>" + unitstring + "</option>"

        '    Unit_Names += unititem

        'Next

    End Sub

End Class
