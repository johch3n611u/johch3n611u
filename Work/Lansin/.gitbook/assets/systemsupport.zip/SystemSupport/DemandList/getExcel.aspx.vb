﻿'/////////////////////////////////////////////////////////////////////////////////
' 會員中心 產出Excel
'
' 建檔人員: 譓茹
' 建檔日期: 2018-05-21
' 修改記錄: 範例--> 日期 記錄人員 簡述
' 關連程式:
' 呼叫來源: 
'/////////////////////////////////////////////////////////////////////////////////
Imports System.Data
Imports EC.Library.Security
Imports System.IO
Partial Class mng_CRM_RFML_getExcel
    Inherits System.Web.UI.Page

    Dim FileName As String = ""
    Dim dr As DataTable = New DataTable
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        FileName = "會員資料.xls"

        Dim selSaleStatusNO As String = RequestString("selSaleStatusNO", RequestActMode.None, RequestMode.None)
        Dim selLastBuyDays As String = RequestString("selLastBuyDays", RequestActMode.None, RequestMode.None)
        Dim selOrderCount As String = RequestString("selOrderCount", RequestActMode.None, RequestMode.None)
        Dim selOrderMoney As String = RequestString("selOrderMoney", RequestActMode.None, RequestMode.None)
        Dim selStartDays As String = RequestString("selStartDays", RequestActMode.None, RequestMode.None)

        Dim acceptEpaper As String = RequestString("acceptEpaper", RequestActMode.None, RequestMode.None)
        Dim isErrorEmail As String = RequestString("isErrorEmail", RequestActMode.None, RequestMode.None)

        Dim sql As String = ""
        sql = <sqla>
                    SELECT *
                      FROM (
                            SELECT cu.cno, 
(case when IsNull(cu.CardNo,'') = '' 
	then (select ls3cMemCardNo from member m where m.cno = cu.cno)
	else cu.CardNo
	end
)as CardNo,
        cu.name, cu.email, cu.mobile, cu.startDate, cu.startDays, 
		                           cu.lastBuyDate, cu.lastBuyDays, cu.orderCount, cu.orderMoney, 
		                           cu.RFML, rn.name RFMLname, cu.acceptEpaper, cu.isErrorEmail,
                                   cu.age,cu.horoscope,cu.birthday,cu.liveCity, REPLACE(c.CityName,' ','') liveCityName,
                                   CASE WHEN cu.sex=1 THEN '男'
                                        ELSE '女'
                                   END sex
                              FROM CRM.dbo.customer cu WITH (NOLOCK)
                              JOIN CRM.dbo.RFML_NoList rn WITH (NOLOCK)
                                ON cu.RFML=rn.No
                              LEFT JOIN city c WITH (NOLOCK)
                                ON cu.liveCity=c.CityNo
                       ) tb
                      {0}
              </sqla>


        Dim Where As String = ""

        If Not String.IsNullOrWhiteSpace(selSaleStatusNO) Then

            selSaleStatusNO = "'" & Replace(selSaleStatusNO, ",", "','") & "'"

            Where = Where & IIf(Not String.IsNullOrWhiteSpace(Where), "AND", "") & " RFML IN ({0}) "
            Where = String.Format(Where, selSaleStatusNO)
        End If

        Dim tmpSql As String = ""
        '=========================================================
        '720天內交易次數(發票數)
        If Not String.IsNullOrWhiteSpace(selOrderCount) Then

            Dim tmpOrderCount As String() = selOrderCount.Split(",")

            tmpSql = "( "
            For i = 0 To tmpOrderCount.Length - 1
                Select Case tmpOrderCount(i)
                    Case "0"
                        tmpSql &= IIf(InStr(tmpSql, "OrderCount") > 0, " OR ", "") & " OrderCount=0 "

                    Case "1"
                        tmpSql &= IIf(InStr(tmpSql, "OrderCount") > 0, " OR ", "") & " OrderCount=1 "

                    Case "2"
                        tmpSql &= IIf(InStr(tmpSql, "OrderCount") > 0, " OR ", "") & " OrderCount BETWEEN 2 AND 3 "

                    Case "4"
                        tmpSql &= IIf(InStr(tmpSql, "OrderCount") > 0, " OR ", "") & " OrderCount>=4 "

                    Case Else
                End Select
            Next
            tmpSql &= " )"

            Where = Where & IIf(Not String.IsNullOrWhiteSpace(Where), "AND", "") & tmpSql
        End If

        '=========================================================
        '720天內交易金額(發票金額) 人數
        If Not String.IsNullOrWhiteSpace(selOrderMoney) Then

            Dim tmpOrderMoney As String() = selOrderMoney.Split(",")

            tmpSql = "( "
            For i = 0 To tmpOrderMoney.Length - 1
                Select Case tmpOrderMoney(i)
                    Case "low"
                        tmpSql &= IIf(InStr(tmpSql, "OrderMoney") > 0, " OR ", "") & " OrderMoney <= 5000 "

                    Case "medium"
                        tmpSql &= IIf(InStr(tmpSql, "OrderMoney") > 0, " OR ", "") & " OrderMoney BETWEEN 5001 AND 30000 "

                    Case "high"
                        tmpSql &= IIf(InStr(tmpSql, "OrderMoney") > 0, " OR ", "") & " OrderMoney >= 30001 "

                    Case Else
                End Select
            Next
            tmpSql &= " )"

            Where = Where & IIf(Not String.IsNullOrWhiteSpace(Where), "AND", "") & tmpSql
        End If

        '=========================================================
        '關係長度 (入會天數) 人數
        If Not String.IsNullOrWhiteSpace(selStartDays) Then

            Dim tmpStartDays As String() = selStartDays.Split(",")

            tmpSql = "( "
            For i = 0 To tmpStartDays.Length - 1
                Select Case tmpStartDays(i)
                    Case "low"
                        tmpSql &= IIf(InStr(tmpSql, "startDays") > 0, " OR ", "") & " startDays <= 90 "

                    Case "medium"
                        tmpSql &= IIf(InStr(tmpSql, "startDays") > 0, " OR ", "") & " startDays BETWEEN 91 AND 720 "

                    Case "high"
                        tmpSql &= IIf(InStr(tmpSql, "startDays") > 0, " OR ", "") & " startDays >= 721 "

                    Case Else
                End Select
            Next
            tmpSql &= " )"

            Where = Where & IIf(Not String.IsNullOrWhiteSpace(Where), "AND", "") & tmpSql
        End If

        '=========================================================
        '最近購買日 人數
        If Not String.IsNullOrWhiteSpace(selLastBuyDays) Then

            Dim tmpLastBuyDays As String() = selLastBuyDays.Split(",")

            tmpSql = "( "
            For i = 0 To tmpLastBuyDays.Length - 1
                Select Case tmpLastBuyDays(i)
                    Case "low"
                        tmpSql &= IIf(InStr(tmpSql, "lastBuyDays") > 0, " OR ", "") & " lastBuyDays <= 90 AND orderCount > 0 "       '當天買 跟 沒買過的 lastBuyDays都會是0 所以要特別排除沒買過的

                    Case "medium"
                        tmpSql &= IIf(InStr(tmpSql, "lastBuyDays") > 0, " OR ", "") & " lastBuyDays BETWEEN 91 AND 360 "

                    Case "high"
                        tmpSql &= IIf(InStr(tmpSql, "lastBuyDays") > 0, " OR ", "") & " lastBuyDays BETWEEN 361 AND 720 "

                    Case Else
                End Select
            Next
            tmpSql &= " )"

            Where = Where & IIf(Not String.IsNullOrWhiteSpace(Where), "AND", "") & tmpSql
        End If

        '=========================================================
        '收電子報
        If Not String.IsNullOrWhiteSpace(acceptEpaper) Then
            Where = Where & IIf(Not String.IsNullOrWhiteSpace(Where), "AND", "") & " acceptEpaper = ({0}) "
            Where = String.Format(Where, acceptEpaper)
        End If

        '非無效名單
        If Not String.IsNullOrWhiteSpace(isErrorEmail) Then
            Where = Where & IIf(Not String.IsNullOrWhiteSpace(Where), "AND", "") & " isErrorEmail = ({0}) "
            Where = String.Format(Where, isErrorEmail)
        End If

        '=========================================================
        'Response.Write(Where)
        'Response.End()

        If Not String.IsNullOrWhiteSpace(Where) Then
            Where = "WHERE " & Where
        End If

        sql = String.Format(sql, Where)

        'Response.Write(sql)
        'Response.End()

        dr = EC.DB.ExecuteDataTable(sql)

        '刪除欄
        dr.Columns.Remove("RFML")

        ''調整欄位名稱 2017-02-14 LERK 註解 改用CSV 輸出
        'dr.Columns("cno").ColumnName = "會員編號"
        'dr.Columns("cardNo").ColumnName = "會員卡號"
        'dr.Columns("email").ColumnName = "Email"
        'dr.Columns("mobile").ColumnName = "手機號碼"
        'dr.Columns("name").ColumnName = "會員姓名"
        'dr.Columns("RFMLname").ColumnName = "RFML會員價值"
        'dr.Columns("startDate").ColumnName = "入會日"
        'dr.Columns("startDays").ColumnName = "入會天數"
        'dr.Columns("lastBuyDate").ColumnName = "最近購買日"
        'dr.Columns("lastBuyDays").ColumnName = "最近購買天數"
        'dr.Columns("orderCount").ColumnName = "720天內交易發票數"
        'dr.Columns("orderMoney").ColumnName = "720天內交易發票總金額"

        'Dim strm As MemoryStream = EC.NPOI.RenderDataTableToExcel(dr)

        'Response.ContentType = "application/vnd.ms-excel"
        'Response.CacheControl = "no-cache"    '避免被 Cache 住
        'Response.Buffer = True
        'Response.Expires = -1
        'Response.AddHeader("Pragma", "no-cache")
        'Response.AddHeader("Content-Disposition", "attachment; filename=" & FileName)
        'Response.BinaryWrite(strm.ToArray)
        'Response.End()

        printCSV()
    End Sub

    ''' <summary>
    ''' 2017-02-14 LERK 新增輸出CSV
    ''' 輸出CSV
    ''' </summary>
    Sub printCSV()

        '產生CSV
        Dim fileDownloadToken As String = RequestString("fileDownloadToken", RequestActMode.None)
        Dim AllStr As StringBuilder = New StringBuilder                     '所有文字訊息
        Dim Str As String = ""                                              '文字訊息

        'CSV 欄位名稱
        Dim csvtitle As String
        csvtitle = "會員編號,會員卡號,Email,手機號碼,會員姓名,RFML會員價值,入會日,入會天數,最近購買日,最近購買天數,720天內交易發票數,720天內交易發票總金額,生日,年紀,居住地點,星座,acceptEpaper,isErrorEmail,性別"

        Dim cno As String = ""                                  '會員編號
        Dim cardNo As String = ""                               '會員卡號
        Dim email As String = ""                                'Email
        Dim mobile As String = ""                               '手機號碼
        Dim name As String = ""                                 '會員姓名
        Dim RFMLname As String = ""                             'RFML會員價值
        Dim startDate As String = ""                            '入會日
        Dim startDays As String = ""                            '入會天數
        Dim lastBuyDate As String = ""                          '最近購買日
        Dim lastBuyDays As String = ""                          '最近購買天數
        Dim orderCount As String = ""                           '一年內消費訂單總筆數
        Dim orderMoney As String = ""                           '一年內消費訂單總金額

        Dim birthday As String = ""                             '生日
        Dim age As String = ""                                  '年齡
        Dim horoscope As String = ""                            '星座
        Dim liveCityName As String = ""                         '居住地區
        Dim buySiteName As String = ""                          '購買門市
        Dim acceptEpaper As String = ""                          '
        Dim isErrorEmail As String = ""                          '
        Dim sex As String = ""                          '性別


        '產生資料
        For i As Integer = 0 To dr.Rows.Count - 1

            cno = dr.Rows(i).Item("cno").ToString                               '會員編號
            cardNo = dr.Rows(i).Item("cardNo").ToString & " "                   '會員卡號
            email = Replace(dr.Rows(i).Item("email").ToString, ",", "")         'Email
            mobile = dr.Rows(i).Item("mobile").ToString & " "                   '手機號碼
            name = dr.Rows(i).Item("name").ToString                             '會員姓名
            RFMLname = dr.Rows(i).Item("RFMLname").ToString                     'RFML會員價值
            startDate = dr.Rows(i).Item("startDate").ToString                   '入會日
            startDays = dr.Rows(i).Item("startDays").ToString                   '入會天數
            lastBuyDate = dr.Rows(i).Item("lastBuyDate").ToString               '最近購買日
            lastBuyDays = dr.Rows(i).Item("lastBuyDays").ToString               '最近購買天數
            birthday = dr.Rows(i).Item("birthday").ToString                 '一年內消費訂單總筆數
            age = dr.Rows(i).Item("age").ToString
            liveCityName = dr.Rows(i).Item("liveCityName").ToString
            horoscope = dr.Rows(i).Item("horoscope").ToString
            acceptEpaper = dr.Rows(i).Item("acceptEpaper").ToString
            isErrorEmail = dr.Rows(i).Item("isErrorEmail").ToString
            sex = dr.Rows(i).Item("sex").ToString

            '一年內消費訂單總金額

            Str = cno & "," &
            cardNo & "," &
            email & "," &
            mobile & "," &
            name & "," &
            RFMLname & "," &
            startDate & "," &
            startDays & "," &
            lastBuyDate & "," &
            lastBuyDays & "," &
            orderCount & "," &
            orderMoney & "," &
            birthday & "," &
            age & "," &
            liveCityName & "," &
            horoscope & "," &
            acceptEpaper & "," &
            isErrorEmail & "," &
            sex

            AllStr.AppendLine(Str)

        Next

        'Response.Write(AllStr.ToString)

        '======================================================================================
        '輸出檔案
        '--------------------------------------------------------------------------------------
        Dim NewName As String = "會員資料({0:yyyyMMdd}).csv"                '檔案名稱
        NewName = String.Format(NewName, Now.Date)

        Response.AppendCookie(New HttpCookie("fileDownloadToken", fileDownloadToken))  'downloadTokenValue will have been provided in the form submit via the hidden input field

        'Response.ContentType = "application/octet-stream"
        Response.ContentType = "text/csv"
        Response.ContentEncoding = System.Text.Encoding.GetEncoding(950)
        Response.Buffer = True
        Response.Expires = -1
        Response.AddHeader("Content-Disposition", "attachment; filename=" & NewName)

        Dim sw As System.IO.StreamWriter =
            New System.IO.StreamWriter(Response.OutputStream, Encoding.GetEncoding(950))
        sw.Write(csvtitle & vbCrLf)
        sw.Write(AllStr.ToString)
        sw.Close()
        '產生CSV-END
    End Sub
End Class
