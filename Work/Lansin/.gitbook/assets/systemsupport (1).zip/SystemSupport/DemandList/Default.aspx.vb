﻿'/////////////////////////////////////////////////////////////////////////////////
' 會員分級資料 - RFML會員定義
' 建檔人員: 譓茹
' 建檔日期: 2018-05-21
' 修改記錄: 
' 關連程式:
' 呼叫來源:
'/////////////////////////////////////////////////////////////////////////////////
Imports EC.Library.Security
Imports System.Data
Partial Class mng_CRM_RFML_Default
    Inherits System.Web.UI.Page

    Public prgname As String = "需求單管理"
    Public PrgID As String = ""
    Public prglimit As EC.mng.Limit       '讀取程式的權限
    Public _currentPath As String = EC.Library.Site.GetCurrentPath   'ex: /mng/Product/Category/LargeNo/

    Dim sql As String = ""
    Dim tb As DataTable = New DataTable


    'chart.js
    Public labels As String = ""
    Public data As String = ""

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Response.CacheControl = "no-cache"             '避免被 Cache 住
        EC.mng.Login.LoginCheck()                      '未登入則導到登入頁
        prglimit = New EC.mng.Limit(ViewState)         '讀取程式的權限
        PrgID = EC.mng.Limit.GetPrgID(ViewState)




        'chart.js
        sql = "SELECT Taxonomy FROM SystemSupport_DemandList With(NOLOCK) WHERE Taxonomy IS NOT NULL AND Taxonomy <> '' GROUP BY Taxonomy"
        tb = EC.DB.ExecuteDataTable(sql)
        Dim list As New List(Of String)
        For num As Integer = 0 To tb.Rows.Count - 1 Step 1
            Dim Taxonomy = tb.Rows.Item(num).Item("Taxonomy").ToString
            list.Add(Taxonomy)

            Dim datasql = "SELECT COUNT(*) FROM SystemSupport_DemandList WHERE Taxonomy = '{0}' "
            datasql = String.Format(datasql, Taxonomy)
            Dim Taxonomycount = EC.DB.ExecuteDataTable(datasql).Select().FirstOrDefault.Item(0).ToString

            Dim labelsstring = "'" + Taxonomy + "'"
            Dim datastring = "'" + Taxonomycount + "'"
            If num <> tb.Rows.Count - 1 Then

                labelsstring += ","
                datastring += ","

            End If
            labels += labelsstring
            data += datastring
        Next







    End Sub
End Class
