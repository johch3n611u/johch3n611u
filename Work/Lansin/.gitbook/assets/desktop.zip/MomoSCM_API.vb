﻿'/////////////////////////////////////////////////////////////////////////////////
' 主程式表單
'
' 建檔人員: 育誠
' 版   本: version 1
' 建檔日期: 2019-11-15
' 參考   : App_Code/YahooShoppingSCM_API.vb ( 原檔案註解較詳細
' 修改記錄: 
' 關連程式:
' 呼叫來源:
'/////////////////////////////////////////////////////////////////////////////////
Imports System.Data
Imports System.IO
Imports System.IO.Compression
Imports System.Net


Public Class MomoSCM_API
    ''' <summary>
    ''' 共用參數
    ''' </summary>
    Private Class CommonParameter
        ''' <summary>
        ''' 登入驗證參數
        ''' </summary>
        Public Class loginInfo
            ''' <summary>
            ''' 精技統一編號
            ''' </summary>
            Public Const VATnumber As String = "12215548"
            ''' <summary>
            ''' 精技MomoSCM密碼
            ''' </summary>
            Public Const SCMpassword As String = "1110193"
            ''' <summary>
            ''' 寄售: 貨權在精技，讓momo銷售
            ''' </summary>
            Public Class Consignment
                ''' <summary>
                ''' 銷售方式 : 寄售
                ''' </summary>
                Public Const salesMethods As String = "Consignment"
                ''' <summary>
                ''' 寄售密碼
                ''' </summary>
                Public Const ConsignmentCode As String = "011560"
                ''' <summary>
                ''' 寄售momoOTP序號V000004118後3碼
                ''' </summary>
                Public Const ConsignmentOTPcode As String = "118"
            End Class
            ''' <summary>
            ''' 買斷: 貨權在momo，在momo銷售
            ''' </summary>
            Public Class Buyout
                ''' <summary>
                ''' 銷售方式 : 買斷
                ''' </summary>
                Public Const salesMethods As String = "Buyout"
                ''' <summary>
                ''' 買斷密碼
                ''' </summary>
                Public Const BuyoutCode As String = "014105"
                ''' <summary>
                ''' 買斷momoOTP序號V000006357後3碼
                ''' </summary>
                Public Const BuyoutOTPcode As String = "357"
            End Class

        End Class
        ''' <summary>
        ''' 步驟參數
        ''' </summary>
        Public Class doAction
            ''' <summary>
            ''' 暫存
            ''' </summary>
            Public Const tempReportGoods As String = "tempReportGoods"
            ''' <summary>
            ''' 送審
            ''' </summary>
            Public Const verifyReportGoods As String = "verifyReportGoods"
        End Class

        ''' <summary>
        ''' 精技固定產地編碼
        ''' </summary>
        Public Shared originCode As String = "0086"

        Public Class Message
            ''' <summary>
            ''' 成功字串
            ''' </summary>
            Public Shared successmsg As String
            ''' <summary>
            ''' 錯誤字串
            ''' </summary>
            Public Shared errormsg As String
        End Class
    End Class

    ''' <summary>
    ''' 上傳資料至MomoSCM，反傳Response String。
    ''' </summary>
    ''' <param name="Method">傳遞方法</param>
    ''' <param name="URL">網址</param>
    ''' <param name="JSONString">JSON傳遞資料</param>
    ''' <returns></returns>
    Public Shared Function Request_MomoSCM_API(Method As String, URL As String, JSONString As String) As String

        '取得雅虎購物中心驗證cookie與wssid
        '***** 將cookie與wssid塞入封包 *****
        '實作 HttpWebRequest
        Dim request As HttpWebRequest = WebRequest.Create(URL) '丟入函數的URL參數
        request.CookieContainer = New CookieContainer()
        request.Method = Method '丟入函數的Method參數
        request.ContentType = "application/json"

        '禁止轉址
        request.AllowAutoRedirect = False
        '內容轉為資料流
        If JSONString <> "" Or JSONString <> Nothing Then
            Dim st As Stream = request.GetRequestStream()
            Dim byteArray As Byte() = Encoding.UTF8.GetBytes(JSONString)
            st.Write(byteArray, 0, byteArray.Length)
        End If
        '執行HttpWebRequest
        Dim response As HttpWebResponse = CType(request.GetResponse(), HttpWebResponse)
        '回傳資料解碼
        Dim reader = New System.IO.StreamReader(response.GetResponseStream(), ASCIIEncoding.UTF8)
        Dim responseText As String = reader.ReadToEnd()
        'Dim Obj As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.JsonConvert.DeserializeObject(responseText)
        '釋放response
        response.Close()
        '回傳API JObject

        Return responseText

    End Function

    ''' <summary>
    ''' 上架商品。
    ''' </summary>
    Public Shared Function POST_proposals_API() As String

        Dim sql = <sql>
                      SELECT * FROM MomoshoppingSCM_API_list WITH(NOLOCK) WHERE posteddate IS NOT NULL
                  </sql>
        Dim dt = EC.DB.ExecuteDataTable(sql)
        Dim ProductNo = dt.Select().FirstOrDefault.Item("ProductNo").ToString
        Dim ecsql As String = <sql>
                      SELECT * FROM list WITH(NOLOCK) WHERE ProductNo = '{0}'
                  </sql>
        ecsql = String.Format(ecsql, ProductNo)
        Dim ecdt = EC.DB.ExecuteDataTable(ecsql)

        For num As Integer = 0 To dt.Rows.Count - 1 Step 1

            Dim obj As MomoSCM.JSONobj = New MomoSCM.JSONobj

            obj.doAction = CommonParameter.doAction.tempReportGoods
            obj.zipFileData = zipFileData_Process(ProductNo)

            Dim salesMethods As String = dt.Select().FirstOrDefault.Item("salesMethods").ToString
            If salesMethods = "買斷" Then

                obj.loginInfo = New MomoSCM.Logininfo
                With obj.loginInfo
                    .entpCode = CommonParameter.loginInfo.VATnumber
                    .entpID = CommonParameter.loginInfo.Buyout.BuyoutCode
                    .entpPwd = CommonParameter.loginInfo.SCMpassword
                    .otpBackNo = CommonParameter.loginInfo.Buyout.BuyoutOTPcode
                End With

            ElseIf salesMethods = "寄賣" Then

                obj.loginInfo = New MomoSCM.Logininfo
                With obj.loginInfo
                    .entpCode = CommonParameter.loginInfo.VATnumber
                    .entpID = CommonParameter.loginInfo.Consignment.ConsignmentCode
                    .entpPwd = CommonParameter.loginInfo.SCMpassword
                    .otpBackNo = CommonParameter.loginInfo.Consignment.ConsignmentOTPcode
                End With
            End If

            obj.sendInfoList() = New List(Of MomoSCM.Sendinfolist)
            Dim sendInfoListValue = New MomoSCM.Sendinfolist
            With sendInfoListValue
                .batchSupNo = ecdt.Select().FirstOrDefault.Item("ProductNo").ToString 'ProductNo
                .supGoodsName_brand = ecdt.Select().FirstOrDefault.Item("brand").ToString 'brand
                .supGoodsName_salePoint = ecdt.Select().FirstOrDefault.Item("ProductName").ToString 'ProductName
                .supGoodsName_serial = ecdt.Select().FirstOrDefault.Item("classics").ToString 'classics
                .isPrompt = dt.Select().FirstOrDefault.Item("isPrompt").ToString
                .isGift = dt.Select().FirstOrDefault.Item("isGift").ToString
                .mainEcCategoryCode = dt.Select().FirstOrDefault.Item("mainEcCategoryCode").ToString
                .webBrandNo = dt.Select().FirstOrDefault.Item("webBrandNo").ToString
                .buyPrice = ecdt.Select().FirstOrDefault.Item("SpicalPrice").ToString 'SpicalPrice
                .salePrice = ecdt.Select().FirstOrDefault.Item("SpicalPrice").ToString 'SpicalPrice
                .custPrice = ecdt.Select().FirstOrDefault.Item("SpicalPrice").ToString 'SpicalPrice
                .goodsType = dt.Select().FirstOrDefault.Item("goodsType").ToString '01:原廠 02:經銷商  03:平行輸入
                .temperatureType = dt.Select().FirstOrDefault.Item("temperatureType").ToString '(常溫、冷凍、冷藏)
                .originCode = CommonParameter.originCode '0086
                .width = dt.Select().FirstOrDefault.Item("width").ToString
                .length = dt.Select().FirstOrDefault.Item("length").ToString
                .height = dt.Select().FirstOrDefault.Item("height").ToString
                .weight = dt.Select().FirstOrDefault.Item("weight").ToString
                '.hasAs = "無"
                '.asDays = ""
                '.asNote = ""
                .isECWarehouse = dt.Select().FirstOrDefault.Item("isECWarehouse").ToString
                .saleUnit = dt.Select().FirstOrDefault.Item("saleUnit").ToString '銷售單位別
                .isPointReachDate = dt.Select().FirstOrDefault.Item("isPointReachDate").ToString
                '.routeMainGroup = ""
                '.routeSubGroup = ""
                '.routeBranchName = ""
                '.drugGoodsCode = "ABC-1234"
                '.isCommission = "否"
                '.isAcceptTravelCard = "否"
                '.isIncludeInstall = "否"
                '.recycleItem = ""
                '.comments = "廠商與MOMO的意見交流"
                '.expDays = ""
                '.etkPromoSdate = ""
                '.etkPromoEdate = ""
                '.etkOfflineDate = ""
                '.trustBankCode = ""
                '.outplaceSeq = ""
                '.outplaceSeqRtn = ""
                '.goodsSpec = "產品內容..."
                '.saleNotice = "銷售注意事項…"
                '.accessories = "3C配件"
                '.giftDesc = "有什麼贈品…"
                '.headline = "2012秋冬新品上市"
                '.content = "質感展現的裝飾領口"
                '.detailInfo = "輕熟主打珍珠領斜接雪紡棉上衣-優雅黑"
                '.ecEntpReturnSeq = ""
                .main_achievement = dt.Select().FirstOrDefault.Item("main_achievement").ToString
                '.youtube_url = ""
                .agreed_delivery_yn = dt.Select().FirstOrDefault.Item("agreed_delivery_yn").ToString
                .tax_yn = dt.Select().FirstOrDefault.Item("tax_yn").ToString
                .disc_mach_yn = dt.Select().FirstOrDefault.Item("disc_mach_yn").ToString
                .gov_subsidize_yn = dt.Select().FirstOrDefault.Item("gov_subsidize_yn").ToString
                '.colSeq1 = "001"
                '.colSeq2 = "002"
            End With


            'sendInfoListValue.indexList() = New List(Of MomoSCM.Indexlist)
            'Dim indexListValue = New MomoSCM.Indexlist
            'With indexListValue
            '    .indexNo = "20160108103334151"
            '    .chosenItemNo = "1"
            'End With
            'sendInfoListValue.indexList().Add(indexListValue)
            'Dim indexListValue2 = New MomoSCM.Indexlist
            'With indexListValue2
            '    .indexNo = "20160128115258992"
            '    .chosenItemNo = "1\t2\t3\t"
            'End With
            'sendInfoListValue.indexList().Add(indexListValue2)


            sendInfoListValue.singleItemList() = New List(Of MomoSCM.Singleitemlist)
            Dim singleitemlistValue = New MomoSCM.Singleitemlist
            With singleitemlistValue
                '.colDetail1 = "紅"
                '.colDetail2 = "斑馬紋"
                '.entpGoodsNo = "def11"
                .internationalNo = ecdt.Select().FirstOrDefault.Item("barCode").ToString 'barCode
                '.prepareQty = "50"
                '.ecFirstQty = ""
                '.ecMinQty = ""
                '.ecLeadTime = ""
                '.specifiedDate = ""
                '.lastSaleDate = ""
                '.branchNameSingle = ""
            End With


            'singleitemlistValue.branchSnList() = New List(Of MomoSCM.Branchsnlist)
            'Dim branchSnListValue = New MomoSCM.Branchsnlist
            'branchSnListValue.branchSn = ""
            'singleitemlistValue.branchSnList().Add(branchSnListValue)
            'Dim branchSnListValue2 = New MomoSCM.Branchsnlist
            'branchSnListValue2.branchSn = ""
            'singleitemlistValue.branchSnList().Add(branchSnListValue2)
            sendInfoListValue.singleItemList().Add(singleitemlistValue)

            'sendInfoListValue.clothData = New MomoSCM.Clothdata
            'With sendInfoListValue.clothData
            '    ._type = "1"
            '    ._unit = "01"
            '    .sizeItemCounts = "1,2,6"
            '    .tryItemCounts = "1,2,3,4,5,6,7,8,9,10"
            'End With

            'sendInfoListValue.clothData.sizeIndexList() = New List(Of MomoSCM.Sizeindexlist)
            'Dim sizeIndexListValue = New MomoSCM.Sizeindexlist
            'sizeIndexListValue.sizeIndex = "M,25,B"
            'sendInfoListValue.clothData.sizeIndexList().Add(sizeIndexListValue)

            'Dim sizeIndexListValue2 = New MomoSCM.Sizeindexlist
            'sizeIndexListValue2.sizeIndex = "L,28,C"
            'sendInfoListValue.clothData.sizeIndexList().Add(sizeIndexListValue2)

            'Dim sizeIndexListValue3 = New MomoSCM.Sizeindexlist
            'sizeIndexListValue3.sizeIndex = "XL,30,D"
            'sendInfoListValue.clothData.sizeIndexList().Add(sizeIndexListValue3)



            'sendInfoListValue.clothData.tryIndexList() = New List(Of MomoSCM.Tryindexlist)
            'Dim tryIndexListValue = New MomoSCM.Tryindexlist
            'tryIndexListValue.tryIndex = "泱泱,M,23,30,26,50,162,45,34B,很舒服"
            'sendInfoListValue.clothData.tryIndexList().Add(tryIndexListValue)

            'Dim tryIndexListValue2 = New MomoSCM.Tryindexlist
            'tryIndexListValue2.tryIndex = "老蕭,M,23,30,26,55,162,55,34C,有點緊，L可能會比較好"
            'sendInfoListValue.clothData.tryIndexList().Add(tryIndexListValue2)


            'sendInfoListValue.mobileDetailInfo = New MomoSCM.Mobiledetailinfo
            'With sendInfoListValue.mobileDetailInfo
            '    .youtubeUrl() = New List(Of String)
            '    .youtubeUrl().Add("12345678901")
            '    .youtubeUrl().Add("1234567902")


            '    .title() = New List(Of String)
            '    .title().Add("標題一")
            '    .title().Add("標題二")
            '    .title().Add("標題三")
            '    .title().Add("標題四")

            '    .content() = New List(Of String)
            '    .content().Add("內容一")
            '    .content().Add("內容二")
            '    .content().Add("內容三")
            '    .content().Add("內容四")
            'End With

            obj.sendInfoList().Add(sendInfoListValue)



            '完成上述結構化迴圈後將obj序列化為api所需json
            Dim JSONobj As String = Newtonsoft.Json.JsonConvert.SerializeObject(obj)

            '★★★★★★★★★★★★★★★★★★★★ "呼叫API並上傳資料" ★★★★★★★★★★★★★★★★★★★★

            Dim URL As String = "https://scmapi.momoshop.com.tw/GoodsServlet.do"

            Try
                Dim Z As String = MomoSCM_API.Request_MomoSCM_API("POST", URL, JSONobj)
                '將資料上傳時的時間從新塞入資料表
                Dim sqlposteddate = "UPDATE MomoshoppingSCM_API_list Set posteddate ='{0}' WHERE ProductNo='{1}'"
                sqlposteddate = String.Format(sqlposteddate, Now, "ProductNo")
                EC.DB.ExecuteScalar(sqlposteddate)
            Catch ex As Exception
                CommonParameter.Message.errormsg += "<font style='color:red'>ProductNo:" + "ProductNo" + "失敗，錯誤訊息 : " + ex.Message + "</font></br>"
                Return CommonParameter.Message.errormsg
            End Try
            CommonParameter.Message.successmsg += "<font style='color:blue'>ProductNo:" + "ProductNo" + "上傳成功</font></br>"
            Return CommonParameter.Message.successmsg

        Next
        Return "暫無新資料需上傳上架API"


        Dim ex_JSONobj = <a>{
    "doAction":"tempReportGoods",
"zipFileData":"UE…(節略)",
    "loginInfo":{
        "entpCode":"001005",
        "entpID":"11223344",
        "entpPwd":"ab1234",
"otpBackNo":"123"
    },
"sendInfoList":[
{
    "batchSupNo":"10001",
    "supGoodsName_brand":"大量品牌",
    "supGoodsName_salePoint":"大量賣點",
    "supGoodsName_serial":"大量系列",
    "isPrompt":"否",
    "isGift":"否",
    "mainEcCategoryCode":"1000600002",
    " webBrandNo":"1702400051",
    "buyPrice":"1200",
    "salePrice":"1583",
    "custPrice":"1800",
    "goodsType":"01",
    "temperatureType":"常溫",
    "originCode":"0886",
    "width":"13",
    "length":"29",
    "height":"15",
    "weight":"8",
    "hasAs":"無",
    "asDays":"",
    "asNote":"",
    "isECWarehouse":"否",
    "saleUnit":"無",
    "isPointReachDate":"否",
    "routeMainGroup":"",
    "routeSubGroup":"",
    "routeBranchName":"",
    "drugGoodsCode":"ABC-1234",
    "isCommission":"否",
    "isAcceptTravelCard":"否",
    "isIncludeInstall":"否",
    "recycleItem":"",
    "comments":"廠商與MOMO的意見交流",
    "expDays":"",
    "etkPromoSdate":"",
    "etkPromoEdate":"",
    "etkOfflineDate":"",
    "trustBankCode":"",
    "outplaceSeq":"",
    "outplaceSeqRtn":"",
    "goodsSpec":"產品內容…",
    "saleNotice":"銷售注意事項…",
	"accessories":"3C配件",
    "giftDesc":"有什麼贈品…",
    "headline":"2012秋冬新品上市",
    "content":"質感展現的裝飾領口",
    "detailInfo":"輕熟主打珍珠領斜接雪紡棉上衣-優雅黑",
    "ecEntpReturnSeq":"",
    "main_achievement":"A0001G0001C0001",
    "youtube_url":"",
    "agreed_delivery_yn":"", 
    "tax_yn":"是", 
    "disc_mach_yn":"", 
    "gov_subsidize_yn":"", 
    "colSeq1":"001",
    "colSeq2":"002",
    "indexList": [
           {
"indexNo": "20160108103334151",
		        "chosenItemNo": "1"
		    },
           {
		        "indexNo": "20160128115258992",
		        "chosenItemNo": "1\t2\t3\t" 
		    }
            
    ],
"singleItemList":[
         {
           "colDetail1":"紅",
           "colDetail2":"斑馬紋",
           "entpGoodsNo":"def11",
           "internationalNo":"1234567890123",
           "prepareQty":"50",
           "ecFirstQty":"",
           "ecMinQty":"",
           "ecLeadTime":"",
           "specifiedDate":"",
           "lastSaleDate":"",
           "branchNameSingle":"",
           "branchSnList":[{"branchSn":""},{"branchSn":""}
           ]
         }
    ],"clothData": {
"_type": "1",
		        "_unit": "01",
		        "sizeItemCounts": "1,2,6",
		        "sizeIndexList": [
{"sizeIndex":"M,25,B"},
{"sizeIndex":"L,28,C"},
{"sizeIndex":"XL,30,D"}
],
		        "tryItemCounts": "1,2,3,4,5,6,7,8,9,10",
		        "tryIndexList": [
{"tryIndex":"泱泱,M,23,30,26,50,162,45,34B,很舒服"},
{"tryIndex":"老蕭,M,23,30,26,55,162,55,34C,有點緊，L可能會比較好"}
]
		},
"mobileDetailInfo": {
			"youtubeUrl": ["12345678901", "1234567902"],
			"title": ["標題一", "標題二", "標題三", "標題四"],
			"content": ["內容一", "內容二", "內容三", "內容四"]
		}
  }
]
}
</a>

    End Function

    ''' <summary>
    ''' URL取圖檔、改規格、改檔名、轉ZIP、塞串流、轉base64
    ''' </summary>
    Public Shared Function zipFileData_Process(ByVal ProductNo As String) As String

        '參考 : http://www.componentace.com/add-stream-to-zip-in-vb.net.htm
        '參考 : https://blog.darkthread.net/blog/zip-byte-array/
        '參考 : https://docs.microsoft.com/zh-tw/dotnet/api/system.io.compression.zipfile?view=netframework-4.8
        '參考 : https://www.cnblogs.com/Mr_JinRui/archive/2010/07/05/1771184.html
        '參考 : https://dotblogs.com.tw/atowngit/2010/01/12/12972
        '參考 : https://codeday.me/bug/20190203/607864.html
        '參考 : https://stackoverflow.com/questions/13053739/when-is-getbuffer-on-memorystream-ever-useful

        '圖檔路徑
        Dim sql As String = <sql>SELECT TOP 1 CategoryA FROM list with(NOLOCK) WHERE ProductNo = '{0}'</sql>
        sql = String.Format(sql, ProductNo)
        Dim dt = EC.DB.ExecuteDataTable(sql)
        Dim imgurl = EC.mng.Info.Eclife_HomeURL & dt.Select().FirstOrDefault.Item("CategoryA").ToString

        '★★★★★★★★★★ URL取圖檔、改規格、改檔名 ★★★★★★★★★★
        Dim WC As System.Net.WebClient = New System.Net.WebClient()
        Dim oldimg As System.Drawing.Image = System.Drawing.Image.FromStream(WC.OpenRead(imgurl))
        Dim newimg = New System.Drawing.Bitmap(oldimg, New System.Drawing.Size(1000, 1000))
        oldimg.Dispose()
        '圖檔改規格後存為串流 詳細請參照MomoSCM上的文件
        Dim imgStream = New MemoryStream()
        newimg.Save(imgStream, System.Drawing.Imaging.ImageFormat.Jpeg)
        newimg.Dispose()
        '固定檔名為(batchSupNo + _B1~...)　詳細請參照MomoSCM上的文件
        Dim newimgfilename = ProductNo + "_B1.jpg"

        '★★★★★★★★★★ Stream 轉 Bytes ★★★★★★★★★★

        'imgStream.Seek(0, SeekOrigin.Begin)
        'Dim buf() As Byte
        'Dim br As BinaryReader = New BinaryReader(imgStream)
        'Dim len As Integer = imgStream.Length
        'buf = br.ReadBytes(len)
        'br.Close()

        Dim bytes(imgStream.Length) As Byte
        imgStream.Seek(0, SeekOrigin.Begin)
        imgStream.Read(bytes, 0, imgStream.Length)

        '★★★★★★★★★★ 轉ZIP、塞串流 ★★★★★★★★★★

        'Dim zipStream = New MemoryStream()
        'Dim zipArchive = New ZipArchive(zipStream, ZipArchiveMode.Update)
        'Dim entry = zipArchive.CreateEntry(newimgfilename)
        'Dim entryStream = entry.Open()
        'entryStream.Seek(0, SeekOrigin.Begin)
        'entryStream.Write(bytes, 0, bytes.Length)

        Dim imgzip
        Dim zipStream = New MemoryStream()
        Using zipStream
            Dim zipArchive = New ZipArchive(zipStream, ZipArchiveMode.Update)
            Using zipArchive
                Dim entry = zipArchive.CreateEntry(newimgfilename)
                Dim entryStream = entry.Open()
                Using entryStream
                    entryStream.Write(bytes, 0, bytes.Length)
                End Using
            End Using
            imgzip = zipStream.ToArray
        End Using

        '★★★★★★★★★★ bytes轉Base64 ★★★★★★★★★★
        Dim base64imgzip = Convert.ToBase64String(imgzip)
        Return base64imgzip
        '解碼測試網址 :　https://cloud.magiclen.org/tw/base64/decoder
    End Function

    ''' <summary>
    ''' 分類查詢。
    ''' </summary>
    Public Shared Function POST_Category_API() As String

        Dim SQL = <SQL>SELECT * FROM MomoshoppingSCM_API_Category WITH(NOLOCK)</SQL>
        Dim DT = EC.DB.ExecuteDataTable(SQL)

        For num As Integer = 0 To DT.Rows.Count - 1 Step 1

            Dim exrequest = <a>{
                              "loginInfo": {
                                      "entpID": "97275166",
                                      "entpCode": "001005",
                                      "entpPwd": "12345678",
                                      "otpBackNo": "111"
                                },
                              "ecCategoryCode": "1300500196"
                           }
                        </a>

            Dim salesMethods() = {CommonParameter.loginInfo.Buyout.salesMethods, CommonParameter.loginInfo.Consignment.salesMethods}
            For Each salesMethod As String In salesMethods

                Dim requestdatalv1 As New Dictionary(Of String, Object)
                Dim requestdatalv2 As New Dictionary(Of String, Object)

                If salesMethod.ToString = "Buyout" Then

                    With requestdatalv2
                        .Add("entpID", CommonParameter.loginInfo.VATnumber)
                        .Add("entpCode", CommonParameter.loginInfo.Buyout.BuyoutCode)
                        .Add("entpPwd", CommonParameter.loginInfo.SCMpassword)
                        .Add("otpBackNo", CommonParameter.loginInfo.Buyout.BuyoutOTPcode)
                    End With

                ElseIf salesMethod.ToString = "Consignment" Then

                    With requestdatalv2
                        .Add("entpID", CommonParameter.loginInfo.VATnumber)
                        .Add("entpCode", CommonParameter.loginInfo.Consignment.ConsignmentCode)
                        .Add("entpPwd", CommonParameter.loginInfo.SCMpassword)
                        .Add("otpBackNo", CommonParameter.loginInfo.Consignment.ConsignmentOTPcode)
                    End With

                End If

                With requestdatalv1
                    .Add("loginInfo", requestdatalv2)
                    .Add("ecCategoryCode", DT.Rows.Item(num).Item("mainEcCategoryCode").ToString)
                End With

                '完成上述結構化迴圈後將obj序列化為api所需json
                Dim JSONobj As String = Newtonsoft.Json.JsonConvert.SerializeObject(requestdatalv1)

                '★★★★★★★★★★★★★★★★★★★★ "呼叫API並上傳資料" ★★★★★★★★★★★★★★★★★★★★

                Dim URL = "https://scmapi.momoshop.com.tw/api/v1/goods/basic_code/ecCategory/D1102.scm"
                Dim QA = <A>HTTP status code：
                    200　[GET]：OK，返回請求資訊。
                    201　[POST]：CREATED，新增或修改成功。
                    400 ：Bad Request，用戶發出的請求有誤，或Server尚未提供此服務。
                    401 ：Unauthorized，表示無權限。
                    422 ：Unprocesable entity，驗證錯誤。
                    500 ：INTERNAL SERVER ERROR，無預期錯誤。
                </A>
                Try
                    Dim Z As String = MomoSCM_API.Request_MomoSCM_API("POST", URL, JSONobj)
                    Dim netJArray As Newtonsoft.Json.Linq.JArray = Newtonsoft.Json.JsonConvert.DeserializeObject(Z)
                    Dim EXJSON = <EXJSON>
                                     {
                                       "CATEGORY_CODE": "1000100005",
                                       "LEVEL1":  "服飾",
                                       "LEVEL2":  "韓國空運",
                                       "LEVEL3":  "女裝",
	                                   "LEVEL4":  "帽T",
	                                   "IS_ AGREED_DELIVERY_YN":  "0",
	                                   "IS_TAX_YN":  "1",
	                                   "IS_DISC_MACH_YN":  "0",
	                                   "IS_GOV_SUBSIDIZE_YN":  "0",
	                                   "IS_MAIN_ACHIEVEMENT_YN":  "1",
	                                   "MAIN_ACHIEVEMENT_NAME":  "商品組合",
	                                   "MAIN_ACHIEVEMENT_LIST": [	
                                               {"ID":"A0003G0002C0002","NAME":"超值禮盒"},
                                               {"ID":"A0003G0002C0003","NAME":"特惠組"},
                                               {"ID":"A0003G0002C0004","NAME":"單品"},
                                               {"ID":"A0003G0002C0005","NAME":"超值禮盒"}
                                                 , {…}
                                                ]
                                     }
                                 </EXJSON>
                    Dim sqlupdata As String =
                                    <sql>UPDATE MomoshoppingSCM_API_Category SET 
                                         IS_AGREED_DELIVERY_YN ='{0}',
                                         IS_TAX_YN ='{1}',
                                         IS_DISC_MACH_YN ='{2}',
                                         IS_GOV_SUBSIDIZE_YN ='{3}',
                                         IS_MAIN_ACHIEVEMENT_YN ='{4}',
                                         MAIN_ACHIEVEMENT_ID = '{5}',
                                         MAIN_ACHIEVEMENT_NAME = '{6}',
                                         posteddate ='{7}'
                                         WHERE mainEcCategoryCode = '{8}'
                                    </sql>
                    '0: 否、1: 是 (提報商品所需)
                    Dim A = netJArray(0).Item("IS_AGREED_DELIVERY_YN").ToString
                    Dim B = netJArray(0).Item("IS_TAX_YN").ToString
                    Dim C = netJArray(0).Item("IS_DISC_MACH_YN").ToString
                    Dim D = netJArray(0).Item("IS_GOV_SUBSIDIZE_YN").ToString
                    Dim E = ""
                    '不確定為何範例有IS_MAIN_ACHIEVEMENT_YN欄位但真實WebAPI回傳欄位無此欄位
                    'Dim E = netJArray(0).Item("IS_MAIN_ACHIEVEMENT_YN").ToString
                    If CStr(netJArray(0).Item("IS_MAIN_ACHIEVEMENT_YN")) <> Nothing Then
                        E = netJArray(0).Item("IS_MAIN_ACHIEVEMENT_YN").ToString
                    End If

                    Dim F As String = ""
                    Dim G As String = ""

                    If E = "" Then
                        For num2 As Integer = 0 To netJArray(0).Item("MAIN_ACHIEVEMENT_LIST").Count - 1 Step 1
                            F += netJArray(0).Item("MAIN_ACHIEVEMENT_LIST")(num2).Item("ID").ToString() + ","
                            G += netJArray(0).Item("MAIN_ACHIEVEMENT_LIST")(num2).Item("NAME").ToString() + ","
                        Next
                    End If

                    Dim H = DT.Rows.Item(num).Item("mainEcCategoryCode").ToString

                    sqlupdata = String.Format(sqlupdata, A, B, C, D, E, F, G, Now, H)

                    EC.DB.ExecuteScalar(sqlupdata)

                Catch ex As Exception
                    CommonParameter.Message.errormsg += "<font style='color:red'>mainEcCategoryCode:" + "ecCategoryCode" + "失敗，錯誤訊息 : " + ex.Message + "</font></br>"
                    'Return CommonParameter.Message.errormsg
                End Try
                CommonParameter.Message.successmsg += "<font style='color:blue'>mainEcCategoryCode:" + "ecCategoryCode" + "上傳成功</font></br>"
                'Return CommonParameter.Message.successmsg

            Next
            'Return "暫無新資料需分類屬性查詢API"
        Next
    End Function

    ''' <summary>
    ''' 分類屬性查詢。
    ''' </summary>
    Public Shared Function POST_AttrIndex_API() As String
        Dim exrequest = <a>{
                              "loginInfo": {
                                      "entpID": "97275166",
                                      "entpCode": "001005",
                                      "entpPwd": "12345678",
                                      "otpBackNo": "111"
                                },
                              "ecCategoryCode": "1300500196"
                           }
                        </a>

        Dim salesMethods() = {CommonParameter.loginInfo.Buyout.salesMethods, CommonParameter.loginInfo.Consignment.salesMethods}
        For Each salesMethod As String In salesMethods

            Dim requestdatalv1 As New Dictionary(Of String, Object)
            Dim requestdatalv2 As New Dictionary(Of String, Object)

            If salesMethod.ToString = "Buyout" Then

                With requestdatalv2
                    .Add("entpID", CommonParameter.loginInfo.VATnumber)
                    .Add("entpCode", CommonParameter.loginInfo.Buyout.BuyoutCode)
                    .Add("entpPwd", CommonParameter.loginInfo.SCMpassword)
                    .Add("otpBackNo", CommonParameter.loginInfo.Buyout.BuyoutOTPcode)
                End With

            ElseIf salesMethod.ToString = "Consignment" Then

                With requestdatalv2
                    .Add("entpID", CommonParameter.loginInfo.VATnumber)
                    .Add("entpCode", CommonParameter.loginInfo.Consignment.ConsignmentCode)
                    .Add("entpPwd", CommonParameter.loginInfo.SCMpassword)
                    .Add("otpBackNo", CommonParameter.loginInfo.Consignment.ConsignmentOTPcode)
                End With

            End If

            With requestdatalv1
                .Add("loginInfo", requestdatalv2)
                .Add("ecCategoryCode", "1300500196")
            End With

            '完成上述結構化迴圈後將obj序列化為api所需json
            Dim JSONobj As String = Newtonsoft.Json.JsonConvert.SerializeObject(requestdatalv1)

            '★★★★★★★★★★★★★★★★★★★★ "呼叫API並上傳資料" ★★★★★★★★★★★★★★★★★★★★

            Dim URL = "https://scmapi.momoshop.com.tw/api/v1/goods/basic_code/ecIndex/D1102.scm"
            Dim QA = <A>HTTP status code：
                    200　[GET]：OK，返回請求資訊。
                    201　[POST]：CREATED，新增或修改成功。
                    400 ：Bad Request，用戶發出的請求有誤，或Server尚未提供此服務。
                    401 ：Unauthorized，表示無權限。
                    422 ：Unprocesable entity，驗證錯誤。
                    500 ：INTERNAL SERVER ERROR，無預期錯誤。
                </A>
            Try
                Dim Z As String = MomoSCM_API.Request_MomoSCM_API("POST", URL, JSONobj)
                '將資料上傳時的時間從新塞入資料表
                Dim sqlposteddate = "UPDATE MomoshoppingSCM_API_AttrIndex Set posteddate ='{0}' WHERE mainEcCategoryCode='{1}'"
                sqlposteddate = String.Format(sqlposteddate, Now, "ecCategoryCode")
                EC.DB.ExecuteScalar(sqlposteddate)
            Catch ex As Exception
                CommonParameter.Message.errormsg += "<font style='color:red'>mainEcCategoryCode:" + "ecCategoryCode" + "失敗，錯誤訊息 : " + ex.Message + "</font></br>"
                'Return CommonParameter.Message.errormsg
            End Try
            CommonParameter.Message.successmsg += "<font style='color:blue'>mainEcCategoryCode:" + "ecCategoryCode" + "上傳成功</font></br>"
            'Return CommonParameter.Message.successmsg

        Next
        'Return "暫無新資料需分類屬性查詢API"
    End Function

    '精技固定產地編碼為0086故不使用此API
    ''' <summary>
    ''' 產地查詢。
    ''' </summary>
    Public Shared Function POST_originCode_API() As String
        Dim exrequest = <a>{
                              "loginInfo": {
                                    "entpID": "97275166",
                                    "entpCode": "001005",
                                    "entpPwd": "12345678",
                                    "otpBackNo": "111"
                              },
                              "originName": "亞"
                            }
                        </a>


        Dim salesMethods() = {CommonParameter.loginInfo.Buyout.salesMethods, CommonParameter.loginInfo.Consignment.salesMethods}
        For Each salesMethod As String In salesMethods

            Dim requestdatalv1 As New Dictionary(Of String, Object)
            Dim requestdatalv2 As New Dictionary(Of String, Object)

            If salesMethod.ToString = "Buyout" Then

                With requestdatalv2
                    .Add("entpID", CommonParameter.loginInfo.VATnumber)
                    .Add("entpCode", CommonParameter.loginInfo.Buyout.BuyoutCode)
                    .Add("entpPwd", CommonParameter.loginInfo.SCMpassword)
                    .Add("otpBackNo", CommonParameter.loginInfo.Buyout.BuyoutOTPcode)
                End With

            ElseIf salesMethod.ToString = "Consignment" Then

                With requestdatalv2
                    .Add("entpID", CommonParameter.loginInfo.VATnumber)
                    .Add("entpCode", CommonParameter.loginInfo.Consignment.ConsignmentCode)
                    .Add("entpPwd", CommonParameter.loginInfo.SCMpassword)
                    .Add("otpBackNo", CommonParameter.loginInfo.Consignment.ConsignmentOTPcode)
                End With

            End If

            With requestdatalv1
                .Add("loginInfo", requestdatalv2)
                .Add("originName", "亞")
            End With


            '完成上述結構化迴圈後將obj序列化為api所需json
            Dim JSONobj As String = Newtonsoft.Json.JsonConvert.SerializeObject(requestdatalv1)

            '★★★★★★★★★★★★★★★★★★★★ "呼叫API並上傳資料" ★★★★★★★★★★★★★★★★★★★★

            Dim URL = "https://scmapi.momoshop.com.tw/api/v1/goods/basic_code/origin/D1102.scm"
            Dim QA = <A>HTTP status code：
                    200　[GET]：OK，返回請求資訊。
                    201　[POST]：CREATED，新增或修改成功。
                    400 ：Bad Request，用戶發出的請求有誤，或Server尚未提供此服務。
                    401 ：Unauthorized，表示無權限。
                    422 ：Unprocesable entity，驗證錯誤。
                    500 ：INTERNAL SERVER ERROR，無預期錯誤。
                </A>
            Try
                Dim Z As String = MomoSCM_API.Request_MomoSCM_API("POST", URL, JSONobj)
                '將資料上傳時的時間從新塞入資料表
                Dim sqlposteddate = "UPDATE MomoshoppingSCM_API_AttrIndex Set posteddate ='{0}' WHERE mainEcCategoryCode='{1}'"
                sqlposteddate = String.Format(sqlposteddate, Now, "ecCategoryCode")
                EC.DB.ExecuteScalar(sqlposteddate)
            Catch ex As Exception
                CommonParameter.Message.errormsg += "<font style='color:red'>mainEcCategoryCode:" + "ecCategoryCode" + "失敗，錯誤訊息 : " + ex.Message + "</font></br>"
                'Return CommonParameter.Message.errormsg
            End Try
            CommonParameter.Message.successmsg += "<font style='color:blue'>mainEcCategoryCode:" + "ecCategoryCode" + "上傳成功</font></br>"
            'Return CommonParameter.Message.successmsg






        Next
        'Return "暫無新資料需分類屬性查詢API"
    End Function

    ''' <summary>
    ''' Momo商品上傳格式類別檔案
    ''' </summary>
    Public Class MomoSCM
        Public Class JSONobj
            Public Property doAction As String
            Public Property zipFileData As String
            Public Property loginInfo As Logininfo
            Public Property sendInfoList() As List(Of Sendinfolist)
        End Class

        Public Class Logininfo
            Public Property entpCode As String
            Public Property entpID As String
            Public Property entpPwd As String
            Public Property otpBackNo As String
        End Class

        Public Class Sendinfolist
            Public Property batchSupNo As String
            Public Property supGoodsName_brand As String
            Public Property supGoodsName_salePoint As String
            Public Property supGoodsName_serial As String
            Public Property isPrompt As String
            Public Property isGift As String
            Public Property mainEcCategoryCode As String
            Public Property webBrandNo As String
            Public Property buyPrice As String
            Public Property salePrice As String
            Public Property custPrice As String
            Public Property goodsType As String
            Public Property temperatureType As String
            Public Property originCode As String
            Public Property width As String
            Public Property length As String
            Public Property height As String
            Public Property weight As String
            'Public Property hasAs As String
            'Public Property asDays As String
            'Public Property asNote As String
            Public Property isECWarehouse As String
            Public Property saleUnit As String
            Public Property isPointReachDate As String
            'Public Property routeMainGroup As String
            'Public Property routeSubGroup As String
            'Public Property routeBranchName As String
            'Public Property drugGoodsCode As String
            'Public Property isCommission As String
            'Public Property isAcceptTravelCard As String
            'Public Property isIncludeInstall As String
            'Public Property recycleItem As String
            'Public Property comments As String
            'Public Property expDays As String
            'Public Property etkPromoSdate As String
            'Public Property etkPromoEdate As String
            'Public Property etkOfflineDate As String
            'Public Property trustBankCode As String
            'Public Property outplaceSeq As String
            'Public Property outplaceSeqRtn As String
            'Public Property goodsSpec As String
            'Public Property saleNotice As String
            'Public Property accessories As String
            'Public Property giftDesc As String
            'Public Property headline As String
            'Public Property content As String
            'Public Property detailInfo As String
            'Public Property ecEntpReturnSeq As String
            Public Property main_achievement As String '業績屬性
            'Public Property youtube_url As String
            Public Property agreed_delivery_yn As String
            Public Property tax_yn As String
            Public Property disc_mach_yn As String
            Public Property gov_subsidize_yn As String
            'Public Property colSeq1 As String
            'Public Property colSeq2 As String
            'Public Property indexList() As List(Of Indexlist)
            Public Property singleItemList() As List(Of Singleitemlist)
            'Public Property clothData As Clothdata
            'Public Property mobileDetailInfo As Mobiledetailinfo
        End Class

        'Public Class Clothdata
        'Public Property _type As String
        'Public Property _unit As String
        'Public Property sizeItemCounts As String
        'Public Property sizeIndexList() As List(Of Sizeindexlist)
        'Public Property tryItemCounts As String
        'Public Property tryIndexList() As List(Of Tryindexlist)
        'End Class

        Public Class Sizeindexlist
            Public Property sizeIndex As String
        End Class

        Public Class Tryindexlist
            Public Property tryIndex As String
        End Class

        'Public Class Mobiledetailinfo
        'Public Property youtubeUrl() As List(Of String)
        'Public Property title() As List(Of String)
        'Public Property content() As List(Of String)
        'End Class

        'Public Class Indexlist
        'Public Property indexNo As String
        'Public Property chosenItemNo As String
        'End Class

        Public Class Singleitemlist
            'Public Property colDetail1 As String
            'Public Property colDetail2 As String
            'Public Property entpGoodsNo As String
            Public Property internationalNo As String
            'Public Property prepareQty As String
            'Public Property ecFirstQty As String
            'Public Property ecMinQty As String
            'Public Property ecLeadTime As String
            'Public Property specifiedDate As String
            'Public Property lastSaleDate As String
            'Public Property branchNameSingle As String
            'Public Property branchSnList() As List(Of Branchsnlist)
        End Class

        'Public Class Branchsnlist
        'Public Property branchSn As String
        'End Class

    End Class
End Class

