﻿
Imports temporarily_header



Partial Class temporarily
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        Dim feedback = temporarily_header.temporarily_header()
        feedback = Split(feedback, ",")
        Dim AAA = feedback(0).ToString
        Dim BBB = feedback(1).ToString
        Response.Write("timestamp = " + AAA + "</br>signature = " + BBB)

    End Sub

End Class
