﻿'/////////////////////////////////////////////////////////////////////////////////
' 儲存選單資料 (新增/修改/刪除)
'
' 建檔人員: 育誠
' 建檔日期: 2019-11-27
' 修改記錄: 範例--> 日期 記錄人員 簡述
' 關連程式:
' 呼叫來源: 
'/////////////////////////////////////////////////////////////////////////////////
Imports System.Data
Imports System.Drawing.Imaging
Imports System.IO
Imports System.Net
Imports AmazonUploadFile
Imports EC.Library.Security
Imports Newtonsoft.Json
Imports YahooShoppingSCM_API

Partial Class mng_product_list_Form_Save
    Inherits System.Web.UI.Page

    Public prglimit As EC.mng.Limit       '讀取程式的權限

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Response.CacheControl = "no-cache"             '避免被 Cache 住
        EC.mng.Login.LoginCheck()                      '未登入則導到登入頁

        Dim action As String = RequestString("action", RequestActMode.None, RequestMode.XSS)    '空值 or del

        Dim errStatus As String = "ok"
        Dim errMessage As String = "儲存完成"

        prglimit = EC.mng.Limit.CheckLimit(ViewState)    '檢查使用者權限
        If prglimit.errStatus = "error" Then   '權限不符
            errStatus = prglimit.errStatus
            errMessage = prglimit.errMessage
        Else  '儲存

            'momo欄位
            Dim ProductNo = RequestString("ProductNo", RequestActMode.None, RequestMode.XSS) & ""
            Dim isPrompt = RequestString("isPrompt", RequestActMode.None, RequestMode.XSS) & ""
            Dim isGift = RequestString("isGift", RequestActMode.None, RequestMode.XSS) & ""
            Dim webBrandNo = RequestString("webBrandNo", RequestActMode.None, RequestMode.XSS) & ""
            Dim goodsType = RequestString("goodsType", RequestActMode.None, RequestMode.XSS) & ""
            Dim temperatureType = RequestString("temperatureType", RequestActMode.None, RequestMode.XSS) & ""
            Dim width = RequestString("width", RequestActMode.None, RequestMode.XSS) & ""
            Dim length = RequestString("length", RequestActMode.None, RequestMode.XSS) & ""
            Dim height = RequestString("height", RequestActMode.None, RequestMode.XSS) & ""
            Dim weight = RequestString("weight", RequestActMode.None, RequestMode.XSS) & ""
            Dim isECWarehouse = RequestString("isECWarehouse", RequestActMode.None, RequestMode.XSS) & ""
            Dim saleUnit = RequestString("saleUnit", RequestActMode.None, RequestMode.XSS) & ""
            Dim isPointReachDate = RequestString("isPointReachDate", RequestActMode.None, RequestMode.XSS) & ""
            Dim mainEcCategoryCode = RequestString("mainEcCategoryCode", RequestActMode.None, RequestMode.XSS) & ""
            Dim salesMethods = RequestString("salesMethods", RequestActMode.None, RequestMode.XSS) & ""

            Dim main_achievement = ""
            Dim agreed_delivery_yn = ""
            Dim tax_yn = ""
            Dim disc_mach_yn = ""
            Dim gov_subsidize_yn = ""

            Try

                Dim sql As String = <sql>
                              DELETE FROM MomoshoppingSCM_API_list
                              WHERE ProductNo ='{0}'
                          </sql>
                sql = String.Format(sql, ProductNo)
                EC.DB.ExecuteScalar(sql)

                sql = <sql>
                            INSERT INTO MomoshoppingSCM_API_list 
                            ( ProductNo,
                              isPrompt,
                              isGift,                              
                              mainEcCategoryCode,                              
                              webBrandNo,                              
                              goodsType,                              
                              temperatureType,                              
                              width,                              
                              length,                              
                              height,                              
                              weight,                              
                              isECWarehouse,                              
                              saleUnit,                              
                              isPointReachDate,                              
                              main_achievement,                              
                              agreed_delivery_yn,                              
                              tax_yn,                              
                              disc_mach_yn,                              
                              gov_subsidize_yn,
                              salesMethods
                            )
                            VALUES 
                            ('{0}',
                             '{1}',
                             '{2}',
                             '{3}',
                             '{4}',
                             '{5}',
                             '{6}',
                             '{7}',
                             '{8}',
                             '{9}',
                             '{10}',
                             '{11}',
                             '{12}',
                             '{13}',
                             '{14}',
                             '{15}',
                             '{16}',
                             '{17}',
                             '{18}',
                             '{19}'
                             )
                      </sql>
                sql = String.Format(sql, ProductNo, isPrompt, isGift, mainEcCategoryCode, webBrandNo, goodsType, temperatureType, width, length, height, weight, isECWarehouse, saleUnit, isPointReachDate, main_achievement, agreed_delivery_yn, tax_yn, disc_mach_yn, gov_subsidize_yn, salesMethods)

                EC.DB.ExecuteScalar(sql)

            Catch ex As Exception
                errStatus = "錯誤"
                errMessage = ex.Message
            End Try

        End If

        Response.Write("[{status: '" & errStatus & "', message:'" & errMessage & "'}]")
    End Sub


End Class




