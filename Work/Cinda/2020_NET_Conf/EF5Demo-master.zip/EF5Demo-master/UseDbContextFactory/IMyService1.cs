﻿namespace UseDbContextFactory
{
    public interface IMyService1
    {
        void WorkIt();
    }
}